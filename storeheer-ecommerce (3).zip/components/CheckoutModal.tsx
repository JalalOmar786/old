"use client"

import type React from "react"

import { useState } from "react"
import { X, CreditCard, Smartphone, Building } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import PaymentInstructions from "./PaymentInstructions"

interface CheckoutModalProps {
  isOpen: boolean
  onClose: () => void
  product: any
  quantity: number
  selectedColor: string
  cartItems?: any[]
}

export default function CheckoutModal({
  isOpen,
  onClose,
  product,
  quantity,
  selectedColor,
  cartItems,
}: CheckoutModalProps) {
  const [formData, setFormData] = useState({
    fullName: "",
    phone: "",
    address: "",
    city: "",
    province: "Punjab",
    promoCode: "",
  })
  const [paymentMethod, setPaymentMethod] = useState("jazzcash")
  const [showPaymentInstructions, setShowPaymentInstructions] = useState(false)
  const [promoDiscount, setPromoDiscount] = useState(0)

  const subtotal = cartItems
    ? cartItems.reduce((total, item) => total + item.price * item.quantity, 0)
    : product.salePrice * quantity
  const shipping = 0 // Free shipping
  const discount = promoDiscount
  const total = subtotal - discount + shipping

  const handlePromoCode = () => {
    if (formData.promoCode.toLowerCase() === "tiktok20") {
      setPromoDiscount(subtotal * 0.2)
    } else if (formData.promoCode.toLowerCase() === "save10") {
      setPromoDiscount(subtotal * 0.1)
    } else {
      setPromoDiscount(0)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setShowPaymentInstructions(true)
  }

  const handleBack = () => {
    setShowPaymentInstructions(false)
  }

  if (!isOpen) return null

  if (showPaymentInstructions) {
    return (
      <PaymentInstructions
        paymentMethod={paymentMethod}
        total={total}
        orderData={{ ...formData, product, quantity, selectedColor, cartItems }}
        onClose={onClose}
        onBack={handleBack}
        onEdit={handleBack}
      />
    )
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-lg font-semibold">Complete Your Order</h2>
          <button onClick={onClose} className="p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Product Summary */}
        <div className="p-4 border-b">
          {cartItems ? (
            <div className="space-y-3">
              <h3 className="font-semibold">Cart Items ({cartItems.length})</h3>
              {cartItems.map((item, index) => (
                <div key={index} className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gray-100 rounded-lg"></div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-sm">{item.name}</h4>
                    <p className="text-sm text-gray-600">
                      Color: {item.color} | Qty: {item.quantity}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">Rs. {item.price * item.quantity}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <div className="w-16 h-16 bg-gray-100 rounded-lg"></div>
              <div className="flex-1">
                <h3 className="font-semibold text-sm">{product.name}</h3>
                <p className="text-sm text-gray-600">Color: {selectedColor}</p>
                <p className="text-sm text-gray-600">Qty: {quantity}</p>
              </div>
              <div className="text-right">
                <p className="font-semibold">Rs. {product.salePrice * quantity}</p>
              </div>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          {/* Customer Information */}
          <div className="space-y-3">
            <div>
              <Label htmlFor="fullName">Full Name *</Label>
              <Input
                id="fullName"
                value={formData.fullName}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="phone">Phone Number *</Label>
              <Input
                id="phone"
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                required
              />
            </div>
            <div>
              <Label htmlFor="address">Complete Address *</Label>
              <Textarea
                id="address"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="city">City *</Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="province">Province</Label>
                <select
                  id="province"
                  value={formData.province}
                  onChange={(e) => setFormData({ ...formData, province: e.target.value })}
                  className="w-full p-2 border rounded-md"
                >
                  <option value="Punjab">Punjab</option>
                  <option value="Sindh">Sindh</option>
                  <option value="KPK">KPK</option>
                  <option value="Balochistan">Balochistan</option>
                </select>
              </div>
            </div>
          </div>

          {/* Promo Code */}
          <div className="border-t pt-4">
            <Label htmlFor="promoCode">Promo Code (Optional)</Label>
            <div className="flex gap-2">
              <Input
                id="promoCode"
                value={formData.promoCode}
                onChange={(e) => setFormData({ ...formData, promoCode: e.target.value })}
                placeholder="Enter TIKTOK20 for 20% off"
              />
              <Button type="button" onClick={handlePromoCode} variant="outline">
                Apply
              </Button>
            </div>
            {promoDiscount > 0 && (
              <p className="text-green-600 text-sm mt-1">Promo applied! You saved Rs. {promoDiscount}</p>
            )}
          </div>

          {/* Payment Method */}
          <div className="border-t pt-4">
            <Label>Payment Method</Label>
            <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="mt-2">
              <div className="flex items-center space-x-2 p-3 border rounded-lg">
                <RadioGroupItem value="jazzcash" id="jazzcash" />
                <Smartphone className="w-5 h-5 text-red-600" />
                <Label htmlFor="jazzcash" className="flex-1">
                  JazzCash (Recommended)
                  <span className="block text-sm text-green-600">Extra 10% discount + Free delivery</span>
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-3 border rounded-lg">
                <RadioGroupItem value="easypaisa" id="easypaisa" />
                <Smartphone className="w-5 h-5 text-green-600" />
                <Label htmlFor="easypaisa" className="flex-1">
                  EasyPaisa
                  <span className="block text-sm text-green-600">Extra 10% discount + Free delivery</span>
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-3 border rounded-lg">
                <RadioGroupItem value="ubl" id="ubl" />
                <Building className="w-5 h-5 text-blue-600" />
                <Label htmlFor="ubl" className="flex-1">
                  UBL Bank Transfer
                  <span className="block text-sm text-blue-600">Account: The Heer - 1307-206316848</span>
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-3 border rounded-lg">
                <RadioGroupItem value="cod" id="cod" />
                <CreditCard className="w-5 h-5 text-gray-600" />
                <Label htmlFor="cod" className="flex-1">
                  Cash on Delivery
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* Order Summary */}
          <div className="border-t pt-4 space-y-2">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span>Rs. {subtotal}</span>
            </div>
            <div className="flex justify-between">
              <span>Shipping:</span>
              <span className="text-green-600">Free</span>
            </div>
            {discount > 0 && (
              <div className="flex justify-between text-green-600">
                <span>Discount:</span>
                <span>-Rs. {discount}</span>
              </div>
            )}
            <div className="flex justify-between font-semibold text-lg border-t pt-2">
              <span>Total:</span>
              <span>Rs. {total}</span>
            </div>
          </div>

          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-semibold py-3"
          >
            Place Order - Rs. {total}
          </Button>
        </form>
      </div>
    </div>
  )
}
