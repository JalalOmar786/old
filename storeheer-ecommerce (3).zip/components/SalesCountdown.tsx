"use client"

import { useState, useEffect } from "react"
import { Clock } from "lucide-react"

export default function SalesCountdown() {
  const [timeLeft, setTimeLeft] = useState({
    hours: 23,
    minutes: 45,
    seconds: 30,
  })

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 }
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 }
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 }
        }
        return prev
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  return (
    <div className="bg-gradient-to-r from-red-500 to-pink-500 text-white p-3 rounded-lg mb-2 shadow-lg">
      <div className="flex items-center justify-center gap-2 mb-1">
        <Clock className="w-4 h-4" />
        <span className="text-sm font-semibold">Sale ends in:</span>
      </div>
      <div className="flex justify-center gap-1">
        <div className="bg-white bg-opacity-20 px-2 py-1 rounded text-xs font-bold">
          {timeLeft.hours.toString().padStart(2, "0")}h
        </div>
        <div className="bg-white bg-opacity-20 px-2 py-1 rounded text-xs font-bold">
          {timeLeft.minutes.toString().padStart(2, "0")}m
        </div>
        <div className="bg-white bg-opacity-20 px-2 py-1 rounded text-xs font-bold">
          {timeLeft.seconds.toString().padStart(2, "0")}s
        </div>
      </div>
    </div>
  )
}
