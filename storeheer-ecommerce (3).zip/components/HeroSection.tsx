import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Star, Zap } from "lucide-react"

export default function HeroSection() {
  return (
    <section className="bg-gradient-to-r from-orange-500 via-red-500 to-pink-500 text-white py-20 mx-4 rounded-2xl mt-8 shadow-2xl">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-flex items-center bg-white bg-opacity-20 backdrop-blur-sm rounded-full px-4 py-2 mb-6">
              <Zap className="w-4 h-4 mr-2 text-yellow-300" />
              <span className="text-sm font-semibold">Limited Time Offer</span>
            </div>

            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Premium Fashion
              <br />
              <span className="text-yellow-300 drop-shadow-lg">80% OFF</span>
            </h1>

            <p className="text-xl mb-8 opacity-90 leading-relaxed">
              Discover our exclusive collection of premium leather handbags, crossbody bags, and fashion accessories.
              Free delivery across Pakistan with 100% refund guarantee.
            </p>

            {/* Trust Indicators */}
            <div className="flex items-center gap-6 mb-8">
              <div className="flex items-center">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <span className="ml-2 font-semibold">4.9/5 (3149 reviews)</span>
              </div>
              <div className="text-sm">
                <span className="font-semibold">10,000+</span> Happy Customers
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/catalog">
                <Button size="lg" className="bg-white text-orange-600 hover:bg-gray-100 shadow-lg font-bold px-8">
                  Shop Now
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link href="/catalog">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-2 border-white text-white hover:bg-white hover:text-orange-600 font-bold px-8"
                >
                  View Catalog
                </Button>
              </Link>
            </div>
          </div>

          <div className="relative">
            <div className="bg-white bg-opacity-20 backdrop-blur-sm rounded-3xl p-8 shadow-2xl">
              <div className="text-center">
                <div className="text-7xl font-bold mb-4 drop-shadow-lg">80%</div>
                <div className="text-2xl mb-6 font-semibold">OFF Everything</div>
                <div className="bg-yellow-400 text-gray-900 px-6 py-3 rounded-full font-bold text-lg shadow-lg">
                  🔥 Sale Ends Soon!
                </div>
              </div>
            </div>

            {/* Floating elements */}
            <div className="absolute -top-4 -right-4 w-20 h-20 bg-yellow-400 rounded-full flex items-center justify-center shadow-lg animate-bounce">
              <span className="text-2xl">🎉</span>
            </div>
            <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-pink-400 rounded-full flex items-center justify-center shadow-lg animate-pulse">
              <span className="text-xl">💝</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
