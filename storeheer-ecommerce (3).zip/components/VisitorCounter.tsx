"use client"

import { useState, useEffect } from "react"
import { Users, Eye } from "lucide-react"

export default function VisitorCounter() {
  const [visitorCount, setVisitorCount] = useState(0)
  const [onlineCount, setOnlineCount] = useState(0)

  useEffect(() => {
    // Generate random visitor count between 2500-6500
    const randomVisitors = Math.floor(Math.random() * (6500 - 2500 + 1)) + 2500
    const randomOnline = Math.floor(Math.random() * (150 - 50 + 1)) + 50

    setVisitorCount(randomVisitors)
    setOnlineCount(randomOnline)

    // Update online count every 30 seconds
    const interval = setInterval(() => {
      const newOnline = Math.floor(Math.random() * (150 - 50 + 1)) + 50
      setOnlineCount(newOnline)
    }, 30000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 mx-4 mb-8 border border-gray-100">
      <div className="grid grid-cols-2 gap-6">
        <div className="text-center">
          <div className="flex items-center justify-center mb-2">
            <Eye className="w-6 h-6 text-blue-600 mr-2" />
            <span className="text-2xl font-bold text-blue-600">{visitorCount.toLocaleString()}</span>
          </div>
          <p className="text-sm text-gray-600 font-medium">Total Visitors Today</p>
        </div>

        <div className="text-center">
          <div className="flex items-center justify-center mb-2">
            <Users className="w-6 h-6 text-green-600 mr-2" />
            <span className="text-2xl font-bold text-green-600">{onlineCount}</span>
          </div>
          <p className="text-sm text-gray-600 font-medium">Online Now</p>
        </div>
      </div>
    </div>
  )
}
