"use client"

import { useState, useEffect } from "react"
import { Clock } from "lucide-react"

export default function CountdownTimer() {
  const [timeLeft, setTimeLeft] = useState({
    hours: 10,
    minutes: 45,
    seconds: 30,
  })

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 }
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 }
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 }
        }
        return prev
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  return (
    <div className="bg-red-50 border border-red-200 p-4 mx-4 rounded-lg mb-4">
      <div className="flex items-center justify-center gap-2 mb-2">
        <Clock className="w-5 h-5 text-red-600" />
        <span className="font-semibold text-red-800">Sale ends in</span>
      </div>
      <div className="flex justify-center gap-2">
        <div className="bg-red-600 text-white px-3 py-2 rounded-lg text-center">
          <div className="text-lg font-bold">{timeLeft.hours.toString().padStart(2, "0")}</div>
          <div className="text-xs">Hours</div>
        </div>
        <div className="bg-red-600 text-white px-3 py-2 rounded-lg text-center">
          <div className="text-lg font-bold">{timeLeft.minutes.toString().padStart(2, "0")}</div>
          <div className="text-xs">Minutes</div>
        </div>
        <div className="bg-red-600 text-white px-3 py-2 rounded-lg text-center">
          <div className="text-lg font-bold">{timeLeft.seconds.toString().padStart(2, "0")}</div>
          <div className="text-xs">Seconds</div>
        </div>
      </div>
    </div>
  )
}
