"use client"

import type React from "react"

import { useState } from "react"
import { X, Copy, Upload, CheckCircle, Download, ArrowLeft, Edit } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

interface PaymentInstructionsProps {
  paymentMethod: string
  total: number
  orderData: any
  onClose: () => void
  onBack?: () => void
  onEdit?: () => void
}

export default function PaymentInstructions({
  paymentMethod,
  total,
  orderData,
  onClose,
  onBack,
  onEdit,
}: PaymentInstructionsProps) {
  const [paymentProof, setPaymentProof] = useState<File | null>(null)
  const [transactionId, setTransactionId] = useState("")
  const [orderSubmitted, setOrderSubmitted] = useState(false)

  const paymentDetails = {
    jazzcash: {
      name: "JazzCash",
      account: "03454928442",
      qrCode: "/images/jazzcash-qr.png",
      instructions: [
        "Open your JazzCash app",
        'Select "Send Money"',
        "Enter the account number: 03454928442",
        "Enter amount: Rs. " + total,
        "Complete the transaction",
        "Take a screenshot and upload below",
      ],
    },
    easypaisa: {
      name: "EasyPaisa",
      account: "03454928442",
      qrCode: "/images/easypaisa-qr.png",
      instructions: [
        "Open your EasyPaisa app",
        'Select "Send Money"',
        "Enter the account number: 03454928442",
        "Enter amount: Rs. " + total,
        "Complete the transaction",
        "Take a screenshot and upload below",
      ],
    },
    ubl: {
      name: "UBL Bank Transfer",
      account: "1307-206316848",
      accountTitle: "The Heer",
      branchCode: "1307",
      instructions: [
        "Visit UBL branch or use UBL mobile app",
        "Transfer to Account: 1307-206316848",
        "Account Title: The Heer",
        "Branch Code: 1307",
        "Enter amount: Rs. " + total,
        "Take a screenshot and upload below",
      ],
    },
  }

  const currentPayment = paymentDetails[paymentMethod as keyof typeof paymentDetails]

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    alert("Account number copied!")
  }

  const downloadQR = (qrCode: string, paymentMethod: string) => {
    const link = document.createElement("a")
    link.href = qrCode
    link.download = `${paymentMethod}-qr-code.png`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setPaymentProof(e.target.files[0])
    }
  }

  const handleSubmitOrder = async () => {
    try {
      const orderId = `SH${Date.now().toString().slice(-6)}`
      const orderDetails = {
        id: orderId,
        customer: orderData.fullName,
        phone: orderData.phone,
        address: orderData.address,
        city: orderData.city,
        province: orderData.province,
        product: orderData.product?.name || "Multiple Items",
        amount: total,
        status: "Pending",
        paymentMethod: currentPayment?.name || paymentMethod,
        date: new Date().toLocaleDateString(),
        timestamp: new Date().toISOString(),
        transactionId,
      }

      // Save order to localStorage
      const existingOrders = JSON.parse(localStorage.getItem("storeheer-orders") || "[]")
      const updatedOrders = [orderDetails, ...existingOrders]
      localStorage.setItem("storeheer-orders", JSON.stringify(updatedOrders))

      // Send email notification
      await fetch("/api/send-notification", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "order",
          email: "theheer@gmail.com",
          phone: "0354928442",
          whatsapp: "0345407608",
          orderDetails,
        }),
      })

      console.log("Order submitted:", orderDetails)
      setOrderSubmitted(true)
    } catch (error) {
      console.error("Error sending notification:", error)
      setOrderSubmitted(true) // Still show success to user
    }
  }

  if (orderSubmitted) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-xl max-w-md w-full p-6 text-center shadow-2xl">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">Order Placed Successfully!</h2>
          <p className="text-gray-600 mb-4">
            Your order has been received. We'll process it within 24 hours and contact you for confirmation.
          </p>
          <p className="text-sm text-gray-500 mb-4">Order ID: #SH{Date.now().toString().slice(-6)}</p>
          <Button onClick={onClose} className="w-full bg-gradient-to-r from-green-500 to-green-600">
            Continue Shopping
          </Button>
        </div>
      </div>
    )
  }

  if (paymentMethod === "cod") {
    const orderId = `SH${Date.now().toString().slice(-6)}`

    // Save COD order
    const orderDetails = {
      id: orderId,
      customer: orderData.fullName,
      phone: orderData.phone,
      address: orderData.address,
      city: orderData.city,
      province: orderData.province,
      product: orderData.product?.name || "Multiple Items",
      amount: total,
      status: "Pending",
      paymentMethod: "Cash on Delivery",
      date: new Date().toLocaleDateString(),
      timestamp: new Date().toISOString(),
    }

    const existingOrders = JSON.parse(localStorage.getItem("storeheer-orders") || "[]")
    const updatedOrders = [orderDetails, ...existingOrders]
    localStorage.setItem("storeheer-orders", JSON.stringify(updatedOrders))

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-xl max-w-md w-full p-6 text-center shadow-2xl">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">Order Confirmed!</h2>
          <p className="text-gray-600 mb-4">
            Your Cash on Delivery order has been placed. You'll pay Rs. {total} when the product is delivered.
          </p>
          <p className="text-sm text-gray-500 mb-4">Order ID: #{orderId}</p>
          <Button onClick={onClose} className="w-full bg-gradient-to-r from-green-500 to-green-600">
            Continue Shopping
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-md w-full max-h-[90vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-lg font-semibold">Payment Instructions</h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation */}
        <div className="flex justify-between p-4 bg-gray-50">
          {onBack && (
            <Button variant="outline" size="sm" onClick={onBack}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          )}
          {onEdit && (
            <Button variant="outline" size="sm" onClick={onEdit}>
              <Edit className="w-4 h-4 mr-2" />
              Edit Order
            </Button>
          )}
        </div>

        <div className="p-4 space-y-4">
          {/* Payment Method */}
          <div className="text-center">
            <h3 className="text-xl font-semibold mb-2">Pay via {currentPayment?.name}</h3>
            <p className="text-2xl font-bold text-green-600">Rs. {total}</p>
          </div>

          {/* Account Details */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex items-center justify-between mb-4">
              <span className="font-semibold">Account Number:</span>
              <div className="flex items-center gap-2">
                <span className="font-mono text-lg font-bold">{currentPayment?.account}</span>
                <Button size="sm" variant="outline" onClick={() => copyToClipboard(currentPayment?.account || "")}>
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* UBL Bank Details */}
            {paymentMethod === "ubl" && (
              <div className="space-y-2 mb-4">
                <div className="flex justify-between">
                  <span className="font-semibold">Account Title:</span>
                  <span>{currentPayment.accountTitle}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-semibold">Branch Code:</span>
                  <span>{currentPayment.branchCode}</span>
                </div>
              </div>
            )}

            {/* QR Code for mobile payments */}
            {(paymentMethod === "jazzcash" || paymentMethod === "easypaisa") && (
              <div className="text-center">
                <img
                  src={currentPayment?.qrCode || "/placeholder.svg"}
                  alt="QR Code"
                  className="w-40 h-40 mx-auto border rounded-lg shadow-lg"
                />
                <p className="text-sm text-gray-600 mt-2 mb-3">Scan QR Code to pay</p>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => downloadQR(currentPayment?.qrCode || "", currentPayment?.name || "")}
                  className="w-full"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Save QR Code
                </Button>
              </div>
            )}
          </div>

          {/* Instructions */}
          <div>
            <h4 className="font-semibold mb-2">Payment Steps:</h4>
            <ol className="space-y-1">
              {currentPayment?.instructions.map((instruction, index) => (
                <li key={index} className="text-sm flex items-start gap-2">
                  <span className="bg-orange-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs flex-shrink-0 mt-0.5">
                    {index + 1}
                  </span>
                  {instruction}
                </li>
              ))}
            </ol>
          </div>

          {/* Upload Payment Proof */}
          <div className="space-y-3">
            <div>
              <Label htmlFor="transactionId">Transaction ID (Optional)</Label>
              <Input
                id="transactionId"
                value={transactionId}
                onChange={(e) => setTransactionId(e.target.value)}
                placeholder="Enter transaction ID"
              />
            </div>
            <div>
              <Label htmlFor="paymentProof">Upload Payment Screenshot *</Label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
                <input type="file" id="paymentProof" accept="image/*" onChange={handleFileUpload} className="hidden" />
                <label htmlFor="paymentProof" className="cursor-pointer">
                  <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                  <p className="text-sm text-gray-600">
                    {paymentProof ? paymentProof.name : "Click to upload screenshot"}
                  </p>
                </label>
              </div>
            </div>
          </div>

          <Button
            onClick={handleSubmitOrder}
            disabled={!paymentProof}
            className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
          >
            Submit Order
          </Button>

          <p className="text-xs text-gray-500 text-center">
            Your order will be processed within 24 hours after payment verification
          </p>
        </div>
      </div>
    </div>
  )
}
