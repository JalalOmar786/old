import Link from "next/link"
import { Mail } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      {/* Trust Badges */}
      <div className="bg-gray-100 py-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mb-2">🏆</div>
              <h3 className="font-semibold text-gray-800">Quality Assurance</h3>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-2">🚚</div>
              <h3 className="font-semibold text-gray-800">On Time Delivery</h3>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-2">💰</div>
              <h3 className="font-semibold text-gray-800">Best Prices</h3>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mb-2">👍</div>
              <h3 className="font-semibold text-gray-800">Return Policy</h3>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* About Us */}
            <div>
              <h3 className="text-xl font-bold mb-4">About Us</h3>
              <p className="text-gray-300 mb-4">
                StoreHeer® is a lifestyle retailer dedicated to inspiring customers through a unique product collection.
              </p>
              <div className="flex items-center text-gray-300">
                <Mail className="w-4 h-4 mr-2" />
                storeheer@gmail.com
              </div>
            </div>

            {/* Our Policies */}
            <div>
              <h3 className="text-xl font-bold mb-4">Our Policies</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/contact-information" className="text-gray-300 hover:text-white">
                    Contact Information
                  </Link>
                </li>
                <li>
                  <Link href="/privacy-policy" className="text-gray-300 hover:text-white">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/refund-policy" className="text-gray-300 hover:text-white">
                    Refund Policy
                  </Link>
                </li>
                <li>
                  <Link href="/shipping-policy" className="text-gray-300 hover:text-white">
                    Shipping Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms-of-service" className="text-gray-300 hover:text-white">
                    Terms of Service
                  </Link>
                </li>
              </ul>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="text-xl font-bold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/" className="text-gray-300 hover:text-white">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/catalog" className="text-gray-300 hover:text-white">
                    Catalog
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="text-gray-300 hover:text-white">
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link href="/admin" className="text-gray-300 hover:text-white">
                    Admin
                  </Link>
                </li>
              </ul>
            </div>

            {/* Newsletter */}
            <div>
              <h3 className="text-xl font-bold mb-4">Subscribe to our newsletter</h3>
              <p className="text-gray-300 mb-4">Sign up to get the latest on sales, new releases and more...</p>
              <div className="flex">
                <Input type="email" placeholder="Your email" className="bg-gray-800 border-gray-700 text-white" />
                <Button className="ml-2 bg-orange-600 hover:bg-orange-700">Subscribe</Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-800 py-4">
        <div className="max-w-7xl mx-auto px-4 text-center text-gray-400">
          <p>&copy; 2025 StoreHeer. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
