"use client"

import { useState, useEffect } from "react"
import { Heart, Share2, Star, Truck, Shield, Clock, Eye, ShoppingCart, Zap, Gift } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import CheckoutModal from "./CheckoutModal"
import ProductGallery from "./ProductGallery"
import ReviewsSection from "./ReviewsSection"
import RecentPurchases from "./RecentPurchases"
import CountdownTimer from "./CountdownTimer"
import SalesCountdown from "./SalesCountdown"
import { useCart } from "@/hooks/useCart"

const product = {
  id: 1,
  name: "Premium Leather Handbag for Women - Crossbody Shoulder Bag",
  originalPrice: 2500,
  salePrice: 499,
  discount: 80,
  rating: 4.9,
  reviewCount: 3149,
  inStock: 32,
  viewingNow: 8,
  images: ["/images/product-1.jpg", "/images/product-2.jpg", "/images/product-3.jpg", "/images/product-4.jpg"],
  colors: ["Black", "Brown", "Red", "White", "Beige"],
  features: [
    "Premium leather material",
    "Multiple compartments",
    "Adjustable strap",
    "Phone pouch included",
    "Perfect for daily use",
  ],
}

export default function ProductPage() {
  const [selectedColor, setSelectedColor] = useState("Black")
  const [quantity, setQuantity] = useState(1)
  const [showCheckout, setShowCheckout] = useState(false)
  const [isSticky, setIsSticky] = useState(false)
  const [isLiked, setIsLiked] = useState(false)
  const [orderKey, setOrderKey] = useState(0)
  const { addToCart, isLoaded } = useCart()

  useEffect(() => {
    const handleScroll = () => {
      setIsSticky(window.scrollY > 100)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const handleLike = () => {
    setIsLiked(!isLiked)
    console.log("Product liked:", !isLiked)
  }

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: product.name,
        text: `Check out this amazing ${product.name} at ${product.discount}% off!`,
        url: window.location.href,
      })
    } else {
      navigator.clipboard.writeText(window.location.href)
      alert("Product link copied to clipboard!")
    }
  }

  const handleAddToCart = () => {
    if (!isLoaded) {
      alert("Please wait, loading cart...")
      return
    }

    try {
      addToCart(
        {
          id: product.id,
          name: product.name,
          price: product.salePrice,
          color: selectedColor,
          image: product.images[0],
        },
        quantity,
      )

      // Show success message
      alert(`✅ ${quantity} x ${product.name} (${selectedColor}) added to cart!`)

      // Force update cart count in header
      window.dispatchEvent(new Event("storage"))
    } catch (error) {
      console.error("Error adding to cart:", error)
      alert("Error adding to cart. Please try again.")
    }
  }

  const handleOrderNow = () => {
    setOrderKey((prev) => prev + 1)
    setShowCheckout(true)
  }

  const handleWhatsAppContact = () => {
    const message = `Hi! I'm interested in ${product.name} (${selectedColor}) - Rs. ${product.salePrice}`
    const whatsappUrl = `https://wa.me/923454076080?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-orange-50">
      {/* Main Content Container with max-width */}
      <div className="max-w-6xl mx-auto">
        {/* Product Gallery */}
        <ProductGallery images={product.images} />

        {/* Promotion Sale Tab */}
        <div className="bg-gradient-to-r from-green-500 to-blue-500 text-white p-4 mx-4 rounded-lg mb-4 shadow-lg">
          <div className="flex items-center justify-center gap-3">
            <Gift className="w-6 h-6" />
            <div className="text-center">
              <h3 className="font-bold text-lg">🎉 PROMOTION SALE 🎉</h3>
              <p className="text-sm">Buy with JazzCash or Easypaisa and get 80% off with free shipping!</p>
            </div>
          </div>
        </div>

        {/* Product Info */}
        <div className="bg-white p-4 shadow-lg mx-4 rounded-lg">
          {/* Price Section */}
          <div className="mb-4">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-3xl font-bold text-green-600">Rs. {product.salePrice}</span>
              <span className="text-lg text-gray-500 line-through">Rs. {product.originalPrice}</span>
              <Badge className="bg-red-500 text-white font-bold">-{product.discount}%</Badge>
            </div>

            {/* Sales Countdown */}
            <SalesCountdown />

            <div className="bg-yellow-100 p-2 rounded-lg mb-4 border border-yellow-300">
              <p className="text-sm font-semibold text-yellow-800">🎉 PAYDAY SALE - Ends in 7 days</p>
            </div>
          </div>

          {/* Product Title */}
          <h1 className="text-lg font-semibold mb-2">{product.name}</h1>

          {/* Rating */}
          <div className="flex items-center gap-2 mb-4">
            <div className="flex items-center">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              ))}
            </div>
            <span className="text-sm text-gray-600">
              {product.rating} ({product.reviewCount})
            </span>
          </div>

          {/* Urgency Indicators */}
          <div className="space-y-2 mb-4">
            <div className="flex items-center gap-2 text-red-600">
              <Clock className="w-4 h-4" />
              <span className="text-sm font-semibold">Hurry Up! Only {product.inStock} left in stock</span>
            </div>
            <div className="flex items-center gap-2 text-orange-600">
              <Eye className="w-4 h-4" />
              <span className="text-sm">{product.viewingNow} people are viewing this right now</span>
            </div>
            <div className="flex items-center gap-2 text-green-600">
              <Truck className="w-4 h-4" />
              <span className="text-sm">Get it between 25 Jun - 27 Jun</span>
            </div>
          </div>

          {/* Color Selection */}
          <div className="mb-4">
            <h3 className="font-semibold mb-2">Color: {selectedColor}</h3>
            <div className="flex gap-2">
              {product.colors.map((color) => (
                <button
                  key={color}
                  onClick={() => setSelectedColor(color)}
                  className={`px-3 py-1 rounded-full border text-sm transition-colors ${
                    selectedColor === color
                      ? "border-orange-500 bg-orange-50 text-orange-600"
                      : "border-gray-300 hover:border-gray-400"
                  }`}
                >
                  {color}
                </button>
              ))}
            </div>
          </div>

          {/* Quantity */}
          <div className="mb-6">
            <h3 className="font-semibold mb-2">Quantity</h3>
            <div className="flex items-center gap-4">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="w-10 h-10 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-100 transition-colors"
              >
                -
              </button>
              <span className="text-lg font-semibold">{quantity}</span>
              <button
                onClick={() => setQuantity(quantity + 1)}
                className="w-10 h-10 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-100 transition-colors"
              >
                +
              </button>
            </div>
          </div>

          {/* Trust Badges */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="flex items-center gap-2 p-3 bg-green-50 rounded-lg border border-green-200">
              <Shield className="w-5 h-5 text-green-600" />
              <div>
                <p className="text-sm font-semibold text-green-800">100% Refund</p>
                <p className="text-xs text-green-600">Guarantee</p>
              </div>
            </div>
            <div className="flex items-center gap-2 p-3 bg-blue-50 rounded-lg border border-blue-200">
              <Truck className="w-5 h-5 text-blue-600" />
              <div>
                <p className="text-sm font-semibold text-blue-800">Free Delivery</p>
                <p className="text-xs text-blue-600">All Pakistan</p>
              </div>
            </div>
          </div>

          {/* Product Features */}
          <div className="mb-6">
            <h3 className="font-semibold mb-2">Product Features</h3>
            <ul className="space-y-1">
              {product.features.map((feature, index) => (
                <li key={index} className="text-sm text-gray-600 flex items-center gap-2">
                  <span className="w-1 h-1 bg-gray-400 rounded-full"></span>
                  {feature}
                </li>
              ))}
            </ul>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={handleLike}
              className={`p-2 rounded-full transition-colors ${isLiked ? "bg-red-100 text-red-500" : "bg-gray-100 text-gray-600"}`}
            >
              <Heart className={`w-6 h-6 ${isLiked ? "fill-current" : ""}`} />
            </button>
            <button
              onClick={handleShare}
              className="p-2 rounded-full bg-gray-100 text-gray-600 hover:bg-blue-100 hover:text-blue-600 transition-colors"
            >
              <Share2 className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Countdown Timer */}
        <CountdownTimer />

        {/* Recent Purchases */}
        <RecentPurchases />

        {/* Reviews Section */}
        <ReviewsSection />

        {/* Sticky Bottom Buttons */}
        <div
          className={`fixed bottom-0 left-0 right-0 bg-white border-t p-4 z-50 transition-transform shadow-2xl ${
            isSticky ? "translate-y-0" : "translate-y-full"
          }`}
        >
          <div className="flex gap-2 max-w-6xl mx-auto">
            <Button
              onClick={handleOrderNow}
              className="flex-1 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-semibold py-3"
            >
              <Zap className="w-4 h-4 mr-2" />
              Order Now
            </Button>
            <Button
              onClick={handleAddToCart}
              variant="outline"
              className="flex-1 border-orange-500 text-orange-600 hover:bg-orange-50 font-semibold py-3"
              disabled={!isLoaded}
            >
              <ShoppingCart className="w-4 h-4 mr-2" />
              {!isLoaded ? "Loading..." : "Add to Cart"}
            </Button>
          </div>
        </div>

        {/* Regular Bottom Buttons with WhatsApp */}
        <div className="bg-white p-4 pb-8 mx-4 rounded-lg">
          <div className="flex gap-2 mb-3">
            <Button
              onClick={handleOrderNow}
              className="flex-1 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-semibold py-3"
            >
              <Zap className="w-4 h-4 mr-2" />
              Order Now - Cash on Delivery
            </Button>
          </div>

          <div className="flex gap-2">
            <Button
              onClick={handleAddToCart}
              variant="outline"
              className="flex-1 border-orange-500 text-orange-600 hover:bg-orange-50 font-semibold py-3"
              disabled={!isLoaded}
            >
              <ShoppingCart className="w-4 h-4 mr-2" />
              {!isLoaded ? "Loading..." : "Add to Cart"}
            </Button>

            {/* WhatsApp Button - Moved here */}
            <Button onClick={handleWhatsAppContact} className="bg-green-500 hover:bg-green-600 text-white px-4 py-3">
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488z" />
              </svg>
            </Button>
          </div>
        </div>
      </div>

      {/* Checkout Modal with key to reset */}
      <CheckoutModal
        key={orderKey}
        isOpen={showCheckout}
        onClose={() => setShowCheckout(false)}
        product={product}
        quantity={quantity}
        selectedColor={selectedColor}
      />
    </div>
  )
}
