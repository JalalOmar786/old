"use client"

import { useState } from "react"
import { Star, ThumbsUp } from "lucide-react"
import { Button } from "@/components/ui/button"

const reviews = [
  {
    id: 1,
    name: "Ayesha K.",
    location: "Karachi",
    rating: 5,
    date: "2 days ago",
    comment: "Amazing quality! The leather is so soft and the bag is perfect for daily use. Highly recommended!",
    verified: true,
    helpful: 12,
  },
  {
    id: 2,
    name: "Fatima S.",
    location: "Lahore",
    rating: 5,
    date: "1 week ago",
    comment: "Love this bag! Great value for money and fast delivery. The color is exactly as shown.",
    verified: true,
    helpful: 8,
  },
  {
    id: 3,
    name: "Zara M.",
    location: "Islamabad",
    rating: 4,
    date: "2 weeks ago",
    comment: "Good quality bag, slightly smaller than expected but still very nice. Good purchase overall.",
    verified: true,
    helpful: 5,
  },
]

export default function ReviewsSection() {
  const [showAllReviews, setShowAllReviews] = useState(false)

  const handleViewAll = () => {
    setShowAllReviews(true)
    // Navigate to reviews page
    window.location.href = "/product/1/reviews"
  }

  return (
    <div className="bg-white p-4 mb-4 shadow-lg rounded-lg mx-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">Ratings and Reviews (3149)</h3>
        <Button
          onClick={handleViewAll}
          variant="outline"
          size="sm"
          className="text-orange-600 border-orange-600 hover:bg-orange-50"
        >
          View All
        </Button>
      </div>

      <div className="space-y-4">
        {reviews.map((review) => (
          <div key={review.id} className="border-b pb-4 last:border-b-0">
            <div className="flex items-start justify-between mb-2">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-semibold text-sm">{review.name}</span>
                  {review.verified && (
                    <span className="bg-green-100 text-green-800 text-xs px-2 py-0.5 rounded">Verified</span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3 h-3 ${i < review.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`}
                      />
                    ))}
                  </div>
                  <span className="text-xs text-gray-500">{review.date}</span>
                </div>
              </div>
            </div>
            <p className="text-sm text-gray-700 mb-2">{review.comment}</p>
            <div className="flex items-center gap-4 text-xs text-gray-500">
              <span>{review.location}</span>
              <button className="flex items-center gap-1 hover:text-gray-700 transition-colors">
                <ThumbsUp className="w-3 h-3" />
                Helpful ({review.helpful})
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
