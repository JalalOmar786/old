"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Star, ShoppingCart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"

const products = [
  {
    id: 1,
    name: "Premium Leather Handbag for Women - Crossbody Shoulder Bag",
    originalPrice: 2500,
    salePrice: 499,
    discount: 80,
    rating: 4.9,
    reviews: 3149,
    image: "/images/product-1.jpg",
    category: "Handbags",
  },
  {
    id: 2,
    name: "Designer Crossbody Bag - Premium Quality",
    originalPrice: 1999,
    salePrice: 399,
    discount: 80,
    rating: 4.8,
    reviews: 2456,
    image: "/images/product-2.jpg",
    category: "Crossbody",
  },
  {
    id: 3,
    name: "Luxury Shoulder Bag - Genuine Leather",
    originalPrice: 3500,
    salePrice: 699,
    discount: 80,
    rating: 4.9,
    reviews: 1876,
    image: "/images/product-3.jpg",
    category: "Shoulder Bags",
  },
  {
    id: 4,
    name: "Casual Phone Pouch - Multi-functional",
    originalPrice: 1200,
    salePrice: 239,
    discount: 80,
    rating: 4.7,
    reviews: 987,
    image: "/images/product-4.jpg",
    category: "Accessories",
  },
  {
    id: 5,
    name: "Business Laptop Bag - Professional Style",
    originalPrice: 4500,
    salePrice: 899,
    discount: 80,
    rating: 4.8,
    reviews: 1543,
    image: "/images/product-5.jpg",
    category: "Business",
  },
  {
    id: 6,
    name: "Trendy Backpack - Urban Collection",
    originalPrice: 2800,
    salePrice: 559,
    discount: 80,
    rating: 4.6,
    reviews: 2134,
    image: "/images/product-6.jpg",
    category: "Backpacks",
  },
  {
    id: 7,
    name: "Elegant Evening Clutch - Party Special",
    originalPrice: 1800,
    salePrice: 359,
    discount: 80,
    rating: 4.9,
    reviews: 876,
    image: "/images/product-7.jpg",
    category: "Accessories",
  },
  {
    id: 8,
    name: "Vintage Messenger Bag - Classic Design",
    originalPrice: 3200,
    salePrice: 639,
    discount: 80,
    rating: 4.7,
    reviews: 1298,
    image: "/images/product-8.jpg",
    category: "Crossbody",
  },
]

const categories = ["All", "Handbags", "Crossbody", "Shoulder Bags", "Accessories", "Business", "Backpacks"]

export default function CatalogContent() {
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [searchTerm, setSearchTerm] = useState("")

  const filteredProducts = products.filter((product) => {
    const matchesCategory = selectedCategory === "All" || product.category === selectedCategory
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesCategory && matchesSearch
  })

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Page Header */}
      <div className="bg-white py-8">
        <div className="max-w-6xl mx-auto px-4">
          <h1 className="text-3xl font-bold text-center mb-4">Our Catalog</h1>
          <p className="text-gray-600 text-center">Discover our complete collection of premium fashion accessories</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Filters */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            {/* Search */}
            <div className="flex-1 max-w-md">
              <Input
                type="text"
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
              />
            </div>

            {/* Categories */}
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className={selectedCategory === category ? "bg-orange-600 hover:bg-orange-700" : ""}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
            >
              <div className="relative aspect-square">
                <Link href={`/product/${product.id}`}>
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    fill
                    className="object-cover cursor-pointer hover:scale-105 transition-transform duration-300"
                  />
                </Link>
                <Badge className="absolute top-2 left-2 bg-red-500 text-white">-{product.discount}%</Badge>
                <Badge className="absolute top-2 right-2 bg-blue-500 text-white text-xs">{product.category}</Badge>
              </div>

              <div className="p-4">
                <Link href={`/product/${product.id}`}>
                  <h3 className="font-semibold mb-2 line-clamp-2 hover:text-orange-600 cursor-pointer">
                    {product.name}
                  </h3>
                </Link>

                <div className="flex items-center gap-1 mb-2">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3 h-3 ${
                          i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-600">({product.reviews})</span>
                </div>

                <div className="flex items-center gap-2 mb-3">
                  <span className="text-lg font-bold text-green-600">Rs. {product.salePrice}</span>
                  <span className="text-sm text-gray-500 line-through">Rs. {product.originalPrice}</span>
                </div>

                <Link href={`/product/${product.id}`}>
                  <Button className="w-full bg-orange-600 hover:bg-orange-700">
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    View Product
                  </Button>
                </Link>
              </div>
            </div>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No products found matching your criteria.</p>
          </div>
        )}
      </div>
    </div>
  )
}
