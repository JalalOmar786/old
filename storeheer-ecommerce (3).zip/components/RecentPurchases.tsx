"use client"

import { useEffect, useState } from "react"
import { CheckCircle, X } from "lucide-react"

const purchaseNotifications = [
  {
    name: "Sana Ahmed",
    location: "Rawalpindi",
    product: "Premium Leather Handbag",
    time: "21 hours ago",
  },
  {
    name: "Maria Khan",
    location: "Karachi",
    product: "Premium Leather Handbag",
    time: "3 hours ago",
  },
  {
    name: "Aisha Ali",
    location: "Lahore",
    product: "Premium Leather Handbag",
    time: "45 minutes ago",
  },
]

export default function RecentPurchases() {
  const [currentNotification, setCurrentNotification] = useState(0)
  const [showNotification, setShowNotification] = useState(true)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentNotification((prev) => (prev + 1) % purchaseNotifications.length)
      setShowNotification(true)

      // Hide notification after 2-3 seconds
      setTimeout(() => {
        setShowNotification(false)
      }, 2500)
    }, 8000)

    return () => clearInterval(interval)
  }, [])

  if (!showNotification) return null

  const notification = purchaseNotifications[currentNotification]

  return (
    <div className="fixed bottom-20 left-4 right-4 z-40 max-w-sm mx-auto">
      <div className="bg-white border border-gray-200 rounded-xl shadow-2xl p-3 flex items-center gap-3 animate-slide-up">
        <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
          <CheckCircle className="w-4 h-4 text-green-600" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs font-semibold text-gray-800 truncate">
            {notification.name} ({notification.location})
          </p>
          <p className="text-xs text-gray-600 truncate">purchased {notification.product}</p>
          <p className="text-xs text-gray-500">{notification.time}</p>
        </div>
        <button onClick={() => setShowNotification(false)} className="text-gray-400 hover:text-gray-600 flex-shrink-0">
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  )
}
