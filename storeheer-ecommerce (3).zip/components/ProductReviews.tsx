"use client"

import { useState } from "react"
import Link from "next/link"
import { Star, ThumbsUp, ArrowLeft, Filter } from "lucide-react"
import { Button } from "@/components/ui/button"

const allReviews = [
  {
    id: 1,
    name: "Ayesha K.",
    location: "Karachi",
    rating: 5,
    date: "2 days ago",
    comment:
      "Amazing quality! The leather is so soft and the bag is perfect for daily use. Highly recommended! The delivery was super fast and the packaging was excellent.",
    verified: true,
    helpful: 12,
  },
  {
    id: 2,
    name: "Fatima S.",
    location: "Lahore",
    rating: 5,
    date: "1 week ago",
    comment:
      "Love this bag! Great value for money and fast delivery. The color is exactly as shown in the pictures. Very satisfied with my purchase.",
    verified: true,
    helpful: 8,
  },
  {
    id: 3,
    name: "Zara M.",
    location: "Islamabad",
    rating: 4,
    date: "2 weeks ago",
    comment:
      "Good quality bag, slightly smaller than expected but still very nice. Good purchase overall. The material feels premium.",
    verified: true,
    helpful: 5,
  },
  {
    id: 4,
    name: "Sana A.",
    location: "Faisalabad",
    rating: 5,
    date: "3 weeks ago",
    comment:
      "Excellent product! The bag is exactly what I was looking for. Perfect size and the quality is outstanding. Will definitely order again.",
    verified: true,
    helpful: 15,
  },
  {
    id: 5,
    name: "Maria K.",
    location: "Multan",
    rating: 4,
    date: "1 month ago",
    comment: "Nice bag with good quality. The delivery was on time and the customer service was helpful. Recommended!",
    verified: true,
    helpful: 7,
  },
]

export default function ProductReviews() {
  const [filterRating, setFilterRating] = useState(0)

  const filteredReviews = filterRating > 0 ? allReviews.filter((review) => review.rating === filterRating) : allReviews

  const averageRating = allReviews.reduce((sum, review) => sum + review.rating, 0) / allReviews.length

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
        <div className="flex items-center gap-4 mb-4">
          <Link href="/product/1">
            <Button variant="outline" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Product
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Customer Reviews</h1>
        </div>

        {/* Rating Summary */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="text-center">
            <div className="text-4xl font-bold text-orange-600 mb-2">{averageRating.toFixed(1)}</div>
            <div className="flex justify-center mb-2">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-5 h-5 ${i < Math.floor(averageRating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`}
                />
              ))}
            </div>
            <p className="text-gray-600">Based on {allReviews.length} reviews</p>
          </div>

          <div className="space-y-2">
            {[5, 4, 3, 2, 1].map((rating) => {
              const count = allReviews.filter((r) => r.rating === rating).length
              const percentage = (count / allReviews.length) * 100
              return (
                <div key={rating} className="flex items-center gap-2">
                  <span className="text-sm w-8">{rating}★</span>
                  <div className="flex-1 bg-gray-200 rounded-full h-2">
                    <div className="bg-yellow-400 h-2 rounded-full" style={{ width: `${percentage}%` }}></div>
                  </div>
                  <span className="text-sm text-gray-600 w-8">{count}</span>
                </div>
              )
            })}
          </div>
        </div>
      </div>

      {/* Filter */}
      <div className="bg-white rounded-xl shadow-lg p-4 mb-6">
        <div className="flex items-center gap-4">
          <Filter className="w-5 h-5 text-gray-600" />
          <span className="font-semibold">Filter by rating:</span>
          <div className="flex gap-2">
            <Button variant={filterRating === 0 ? "default" : "outline"} size="sm" onClick={() => setFilterRating(0)}>
              All
            </Button>
            {[5, 4, 3, 2, 1].map((rating) => (
              <Button
                key={rating}
                variant={filterRating === rating ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterRating(rating)}
              >
                {rating}★
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* Reviews List */}
      <div className="space-y-4">
        {filteredReviews.map((review) => (
          <div key={review.id} className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-start justify-between mb-3">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-semibold">{review.name}</span>
                  {review.verified && (
                    <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                      Verified Purchase
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${i < review.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-500">{review.date}</span>
                </div>
              </div>
            </div>

            <p className="text-gray-700 mb-3 leading-relaxed">{review.comment}</p>

            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-500">{review.location}</span>
              <button className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700 transition-colors">
                <ThumbsUp className="w-4 h-4" />
                Helpful ({review.helpful})
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredReviews.length === 0 && (
        <div className="bg-white rounded-xl shadow-lg p-8 text-center">
          <p className="text-gray-500">No reviews found for the selected rating.</p>
        </div>
      )}
    </div>
  )
}
