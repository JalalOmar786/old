import Header from "@/components/Header"
import Footer from "@/components/Footer"
import CartContent from "@/components/CartContent"

export default function CartPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <CartContent />
      <Footer />
    </div>
  )
}
