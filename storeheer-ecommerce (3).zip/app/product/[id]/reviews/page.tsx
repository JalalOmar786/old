import Header from "@/components/Header"
import Footer from "@/components/Footer"
import ProductReviews from "@/components/ProductReviews"

export default function ProductReviewsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-orange-50">
      <Header />
      <ProductReviews />
      <Footer />
    </div>
  )
}
