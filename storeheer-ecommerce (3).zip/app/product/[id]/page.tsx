"use client"

import { useEffect } from "react"
import Header from "@/components/Header"
import Footer from "@/components/Footer"
import ProductPage from "@/components/ProductPage"

export default function ProductDetailPage() {
  // Fix mobile scroll to top issue
  useEffect(() => {
    // Scroll to top when component mounts
    window.scrollTo(0, 0)

    // Also scroll to top after a short delay to ensure content is loaded
    const timer = setTimeout(() => {
      window.scrollTo(0, 0)
    }, 100)

    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="min-h-screen">
      <Header />
      <ProductPage />
      <Footer />
    </div>
  )
}
