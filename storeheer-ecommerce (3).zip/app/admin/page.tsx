"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  Plus,
  Edit,
  Trash2,
  Package,
  DollarSign,
  LogOut,
  RefreshCw,
  Eye,
  X,
  Save,
  Upload,
  Star,
  Clock,
  Tag,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface Order {
  id: string
  customer: string
  phone: string
  product: string
  amount: number
  status: string
  paymentMethod: string
  date: string
  address: string
  city: string
  province: string
  timestamp?: string
  transactionId?: string
}

interface Product {
  id: number
  name: string
  price: number
  originalPrice: number
  stock: number
  status: string
  description: string
  features: string[]
  images: string[]
  colors: string[]
  category: string
  rating: number
  reviews: number
  sku: string
}

interface Review {
  id: string
  productId: number
  customerName: string
  rating: number
  comment: string
  date: string
  verified: boolean
}

interface PromoCode {
  id: string
  code: string
  discount: number
  type: "percentage" | "fixed"
  active: boolean
  expiryDate: string
  usageLimit: number
  usedCount: number
}

interface SalesPromotion {
  id: string
  title: string
  description: string
  discountPercentage: number
  startDate: string
  endDate: string
  active: boolean
  timerEnabled: boolean
}

const mockProducts: Product[] = [
  {
    id: 1,
    name: "Premium Leather Handbag for Women - Crossbody Shoulder Bag",
    price: 499,
    originalPrice: 2500,
    stock: 32,
    status: "Active",
    description: "Premium quality leather handbag for women with crossbody and shoulder strap options",
    features: [
      "Premium leather material",
      "Multiple compartments",
      "Adjustable strap",
      "Phone pouch included",
      "Perfect for daily use",
    ],
    images: ["/images/product-1.jpg", "/images/handbag-1.jpg"],
    colors: ["Black", "Brown", "Red", "White", "Beige"],
    category: "Handbags",
    rating: 4.9,
    reviews: 3149,
    sku: "HB001",
  },
  {
    id: 2,
    name: "Designer Crossbody Bag - Premium Quality",
    price: 399,
    originalPrice: 1999,
    stock: 25,
    status: "Active",
    description: "Stylish designer crossbody bag perfect for daily use and special occasions",
    features: ["Designer quality", "Compact size", "Durable material", "Adjustable strap", "Multiple pockets"],
    images: ["/images/product-2.jpg", "/images/handbag-2.jpg"],
    colors: ["Black", "White", "Beige", "Navy"],
    category: "Crossbody",
    rating: 4.8,
    reviews: 2456,
    sku: "CB001",
  },
  {
    id: 3,
    name: "Luxury Shoulder Bag - Genuine Leather",
    price: 699,
    originalPrice: 3500,
    stock: 18,
    status: "Active",
    description: "Luxury genuine leather shoulder bag with elegant design and premium finish",
    features: ["Genuine leather", "Luxury design", "Spacious interior", "Premium hardware", "Elegant finish"],
    images: ["/images/product-3.jpg", "/images/handbag-3.jpg"],
    colors: ["Black", "Brown", "Burgundy", "Tan"],
    category: "Shoulder Bags",
    rating: 4.9,
    reviews: 1876,
    sku: "SB001",
  },
  {
    id: 4,
    name: "Casual Phone Pouch - Multi-functional",
    price: 239,
    originalPrice: 1200,
    stock: 45,
    status: "Active",
    description: "Multi-functional phone pouch with card slots and coin compartment",
    features: ["Phone compartment", "Card slots", "Coin pocket", "Wrist strap", "Compact design"],
    images: ["/images/product-4.jpg", "/images/handbag-4.jpg"],
    colors: ["Black", "Pink", "Blue", "Green"],
    category: "Accessories",
    rating: 4.7,
    reviews: 987,
    sku: "PP001",
  },
  {
    id: 5,
    name: "Business Laptop Bag - Professional Style",
    price: 899,
    originalPrice: 4500,
    stock: 12,
    status: "Active",
    description: "Professional laptop bag perfect for business meetings and office use",
    features: [
      "Laptop compartment",
      "Document pockets",
      "Professional design",
      "Durable material",
      "Comfortable handles",
    ],
    images: ["/images/product-5.jpg"],
    colors: ["Black", "Brown", "Navy"],
    category: "Business",
    rating: 4.8,
    reviews: 1543,
    sku: "LB001",
  },
  {
    id: 6,
    name: "Trendy Backpack - Urban Collection",
    price: 559,
    originalPrice: 2800,
    stock: 28,
    status: "Active",
    description: "Trendy urban backpack with modern design and multiple compartments",
    features: ["Multiple compartments", "Padded straps", "Urban design", "Water resistant", "Laptop sleeve"],
    images: ["/images/product-6.jpg"],
    colors: ["Black", "Gray", "Navy", "Olive"],
    category: "Backpacks",
    rating: 4.6,
    reviews: 2134,
    sku: "BP001",
  },
  {
    id: 7,
    name: "Elegant Evening Clutch - Party Special",
    price: 359,
    originalPrice: 1800,
    stock: 35,
    status: "Active",
    description: "Elegant evening clutch perfect for parties and special occasions",
    features: ["Elegant design", "Compact size", "Chain strap", "Premium finish", "Party perfect"],
    images: ["/images/product-7.jpg"],
    colors: ["Black", "Gold", "Silver", "Rose Gold"],
    category: "Accessories",
    rating: 4.9,
    reviews: 876,
    sku: "EC001",
  },
  {
    id: 8,
    name: "Vintage Messenger Bag - Classic Design",
    price: 639,
    originalPrice: 3200,
    stock: 20,
    status: "Active",
    description: "Classic vintage messenger bag with timeless design and durable construction",
    features: ["Vintage design", "Durable canvas", "Leather accents", "Adjustable strap", "Multiple pockets"],
    images: ["/images/product-8.jpg"],
    colors: ["Brown", "Khaki", "Black", "Olive"],
    category: "Crossbody",
    rating: 4.7,
    reviews: 1298,
    sku: "MB001",
  },
]

const mockReviews: Review[] = [
  {
    id: "1",
    productId: 1,
    customerName: "Ayesha K.",
    rating: 5,
    comment: "Amazing quality! The leather is so soft and the bag is perfect for daily use.",
    date: "2024-01-15",
    verified: true,
  },
  {
    id: "2",
    productId: 1,
    customerName: "Fatima S.",
    rating: 4,
    comment: "Good quality bag, fast delivery. Recommended!",
    date: "2024-01-10",
    verified: true,
  },
]

export default function AdminDashboard() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [loading, setLoading] = useState(true)
  const [orders, setOrders] = useState<Order[]>([])
  const [products, setProducts] = useState<Product[]>(mockProducts)
  const [reviews, setReviews] = useState<Review[]>(mockReviews)
  const [promoCodes, setPromoCodes] = useState<PromoCode[]>([
    {
      id: "1",
      code: "TIKTOK20",
      discount: 20,
      type: "percentage",
      active: true,
      expiryDate: "2024-12-31",
      usageLimit: 1000,
      usedCount: 45,
    },
    {
      id: "2",
      code: "SAVE10",
      discount: 10,
      type: "percentage",
      active: true,
      expiryDate: "2024-12-31",
      usageLimit: 500,
      usedCount: 23,
    },
  ])
  const [salesPromotions, setSalesPromotions] = useState<SalesPromotion[]>([
    {
      id: "1",
      title: "PAYDAY SALE",
      description: "80% off on all products",
      discountPercentage: 80,
      startDate: "2024-01-01",
      endDate: "2024-12-31",
      active: true,
      timerEnabled: true,
    },
  ])
  const [paymentSettings, setPaymentSettings] = useState({
    jazzcash: "03454928442",
    easypaisa: "03454928442",
    ubl: "1307-206316848 (The Heer)",
  })

  const [checkoutSettings, setCheckoutSettings] = useState({
    // Payment Methods
    jazzcashEnabled: true,
    easypaisaEnabled: true,
    ublEnabled: true,
    codEnabled: true,
    jazzcashDiscount: 10,
    easypaisaDiscount: 10,

    // Shipping Settings
    freeShipping: true,
    shippingCost: 0,
    shippingMessage: "Free shipping nationwide",

    // Form Fields
    requiredFields: {
      fullName: true,
      phone: true,
      address: true,
      city: true,
      province: true,
    },

    // Payment Instructions
    jazzcashInstructions: [
      "Open your JazzCash app",
      'Select "Send Money"',
      "Enter the account number: 03454928442",
      "Enter amount: Rs. {amount}",
      "Complete the transaction",
      "Take a screenshot and upload below",
    ],
    easypaisaInstructions: [
      "Open your EasyPaisa app",
      'Select "Send Money"',
      "Enter the account number: 03454928442",
      "Enter amount: Rs. {amount}",
      "Complete the transaction",
      "Take a screenshot and upload below",
    ],
    ublInstructions: [
      "Visit UBL branch or use UBL mobile app",
      "Transfer to Account: 1307-206316848",
      "Account Title: The Heer",
      "Branch Code: 1307",
      "Enter amount: Rs. {amount}",
      "Take a screenshot and upload below",
    ],

    // Order Confirmation
    successMessage: "Your order has been received. We'll process it within 24 hours and contact you for confirmation.",
    codMessage: "Your Cash on Delivery order has been placed. You'll pay Rs. {amount} when the product is delivered.",

    // Province Options
    provinces: ["Punjab", "Sindh", "KPK", "Balochistan", "Islamabad", "AJK", "Gilgit-Baltistan"],
  })

  const [showAddProduct, setShowAddProduct] = useState(false)
  const [showOrderDetails, setShowOrderDetails] = useState<Order | null>(null)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [showAddPromo, setShowAddPromo] = useState(false)
  const [showAddPromotion, setShowAddPromotion] = useState(false)
  const [showAddReview, setShowAddReview] = useState(false)
  const [selectedProductForReview, setSelectedProductForReview] = useState<number | null>(null)

  const [newProduct, setNewProduct] = useState({
    name: "",
    price: "",
    originalPrice: "",
    stock: "",
    description: "",
    features: "",
    category: "",
    sku: "",
    colors: "",
    images: [] as string[],
  })

  const [newPromo, setNewPromo] = useState({
    code: "",
    discount: "",
    type: "percentage" as "percentage" | "fixed",
    expiryDate: "",
    usageLimit: "",
  })

  const [newPromotion, setNewPromotion] = useState({
    title: "",
    description: "",
    discountPercentage: "",
    startDate: "",
    endDate: "",
    timerEnabled: false,
  })

  const [newReview, setNewReview] = useState({
    customerName: "",
    rating: 5,
    comment: "",
    verified: true,
  })

  const router = useRouter()

  // Check authentication
  useEffect(() => {
    const checkAuth = () => {
      const isAuth = localStorage.getItem("admin-authenticated")
      const loginTime = localStorage.getItem("admin-login-time")

      if (isAuth === "true" && loginTime) {
        const timeDiff = Date.now() - Number.parseInt(loginTime)
        const hoursDiff = timeDiff / (1000 * 60 * 60)

        if (hoursDiff < 24) {
          setIsAuthenticated(true)
          loadOrders()
        } else {
          localStorage.removeItem("admin-authenticated")
          localStorage.removeItem("admin-login-time")
          router.push("/admin/login")
        }
      } else {
        router.push("/admin/login")
      }
      setLoading(false)
    }

    checkAuth()
  }, [router])

  const loadOrders = () => {
    try {
      const savedOrders = localStorage.getItem("storeheer-orders")
      if (savedOrders) {
        const parsedOrders = JSON.parse(savedOrders)
        setOrders(parsedOrders)
      }
    } catch (error) {
      console.error("Error loading orders:", error)
    }
  }

  const refreshOrders = () => {
    loadOrders()
  }

  const handleLogout = () => {
    localStorage.removeItem("admin-authenticated")
    localStorage.removeItem("admin-login-time")
    router.push("/admin/login")
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, isEditing = false) => {
    const files = e.target.files
    if (files) {
      const imageUrls: string[] = []
      Array.from(files).forEach((file) => {
        const reader = new FileReader()
        reader.onload = (event) => {
          const imageUrl = event.target?.result as string
          imageUrls.push(imageUrl)

          if (isEditing && editingProduct) {
            setEditingProduct({
              ...editingProduct,
              images: [...editingProduct.images, imageUrl],
            })
          } else {
            setNewProduct({
              ...newProduct,
              images: [...newProduct.images, imageUrl],
            })
          }
        }
        reader.readAsDataURL(file)
      })
    }
  }

  const removeImage = (index: number, isEditing = false) => {
    if (isEditing && editingProduct) {
      const updatedImages = editingProduct.images.filter((_, i) => i !== index)
      setEditingProduct({ ...editingProduct, images: updatedImages })
    } else {
      const updatedImages = newProduct.images.filter((_, i) => i !== index)
      setNewProduct({ ...newProduct, images: updatedImages })
    }
  }

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault()
    const product: Product = {
      id: products.length + 1,
      name: newProduct.name,
      price: Number.parseInt(newProduct.price),
      originalPrice: Number.parseInt(newProduct.originalPrice),
      stock: Number.parseInt(newProduct.stock),
      status: "Active",
      description: newProduct.description,
      features: newProduct.features.split("\n").filter((f) => f.trim()),
      images: newProduct.images,
      colors: newProduct.colors
        .split(",")
        .map((c) => c.trim())
        .filter((c) => c),
      category: newProduct.category,
      rating: 0,
      reviews: 0,
      sku: newProduct.sku,
    }
    setProducts([...products, product])
    setNewProduct({
      name: "",
      price: "",
      originalPrice: "",
      stock: "",
      description: "",
      features: "",
      category: "",
      sku: "",
      colors: "",
      images: [],
    })
    setShowAddProduct(false)
    alert("Product added successfully!")
  }

  const handleEditProduct = (product: Product) => {
    setEditingProduct({
      ...product,
      features: product.features?.join("\n") || "",
      colors: product.colors?.join(", ") || "",
    })
  }

  const handleUpdateProduct = (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingProduct) return

    const updatedProducts = products.map((p) =>
      p.id === editingProduct.id
        ? {
            ...editingProduct,
            price: Number.parseInt(editingProduct.price.toString()),
            originalPrice: Number.parseInt(editingProduct.originalPrice.toString()),
            stock: Number.parseInt(editingProduct.stock.toString()),
            features: editingProduct.features
              .toString()
              .split("\n")
              .filter((f: string) => f.trim()),
            colors: editingProduct.colors
              .toString()
              .split(",")
              .map((c: string) => c.trim())
              .filter((c: string) => c),
          }
        : p,
    )
    setProducts(updatedProducts)
    setEditingProduct(null)
    alert("Product updated successfully!")
  }

  const handleDeleteProduct = (productId: number) => {
    if (confirm("Are you sure you want to delete this product?")) {
      setProducts(products.filter((p) => p.id !== productId))
      alert("Product deleted successfully!")
    }
  }

  const updateOrderStatus = (orderId: string, newStatus: string) => {
    const updatedOrders = orders.map((order) => (order.id === orderId ? { ...order, status: newStatus } : order))
    setOrders(updatedOrders)
    localStorage.setItem("storeheer-orders", JSON.stringify(updatedOrders))
  }

  const handleAddPromo = (e: React.FormEvent) => {
    e.preventDefault()
    const promo: PromoCode = {
      id: Date.now().toString(),
      code: newPromo.code.toUpperCase(),
      discount: Number.parseInt(newPromo.discount),
      type: newPromo.type,
      active: true,
      expiryDate: newPromo.expiryDate,
      usageLimit: Number.parseInt(newPromo.usageLimit),
      usedCount: 0,
    }
    setPromoCodes([...promoCodes, promo])
    setNewPromo({ code: "", discount: "", type: "percentage", expiryDate: "", usageLimit: "" })
    setShowAddPromo(false)
    alert("Promo code added successfully!")
  }

  const handleAddPromotion = (e: React.FormEvent) => {
    e.preventDefault()
    const promotion: SalesPromotion = {
      id: Date.now().toString(),
      title: newPromotion.title,
      description: newPromotion.description,
      discountPercentage: Number.parseInt(newPromotion.discountPercentage),
      startDate: newPromotion.startDate,
      endDate: newPromotion.endDate,
      active: true,
      timerEnabled: newPromotion.timerEnabled,
    }
    setSalesPromotions([...salesPromotions, promotion])
    setNewPromotion({
      title: "",
      description: "",
      discountPercentage: "",
      startDate: "",
      endDate: "",
      timerEnabled: false,
    })
    setShowAddPromotion(false)
    alert("Sales promotion added successfully!")
  }

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedProductForReview) return

    const review: Review = {
      id: Date.now().toString(),
      productId: selectedProductForReview,
      customerName: newReview.customerName,
      rating: newReview.rating,
      comment: newReview.comment,
      date: new Date().toISOString().split("T")[0],
      verified: newReview.verified,
    }
    setReviews([...reviews, review])

    // Update product rating
    const productReviews = [...reviews, review].filter((r) => r.productId === selectedProductForReview)
    const avgRating = productReviews.reduce((sum, r) => sum + r.rating, 0) / productReviews.length

    setProducts(
      products.map((p) =>
        p.id === selectedProductForReview
          ? { ...p, rating: Math.round(avgRating * 10) / 10, reviews: productReviews.length }
          : p,
      ),
    )

    setNewReview({ customerName: "", rating: 5, comment: "", verified: true })
    setShowAddReview(false)
    setSelectedProductForReview(null)
    alert("Review added successfully!")
  }

  const togglePromoStatus = (promoId: string) => {
    setPromoCodes(promoCodes.map((p) => (p.id === promoId ? { ...p, active: !p.active } : p)))
  }

  const togglePromotionStatus = (promotionId: string) => {
    setSalesPromotions(salesPromotions.map((p) => (p.id === promotionId ? { ...p, active: !p.active } : p)))
  }

  const deletePromo = (promoId: string) => {
    if (confirm("Are you sure you want to delete this promo code?")) {
      setPromoCodes(promoCodes.filter((p) => p.id !== promoId))
      alert("Promo code deleted!")
    }
  }

  const deletePromotion = (promotionId: string) => {
    if (confirm("Are you sure you want to delete this promotion?")) {
      setSalesPromotions(salesPromotions.filter((p) => p.id !== promotionId))
      alert("Promotion deleted!")
    }
  }

  const deleteReview = (reviewId: string) => {
    if (confirm("Are you sure you want to delete this review?")) {
      setReviews(reviews.filter((r) => r.id !== reviewId))
      alert("Review deleted!")
    }
  }

  const handleUpdatePaymentSettings = () => {
    alert("Payment settings updated successfully!")
  }

  const handleUpdateCheckoutSettings = () => {
    // Save checkout settings to localStorage for persistence
    localStorage.setItem("storeheer-checkout-settings", JSON.stringify(checkoutSettings))
    alert("Checkout settings updated successfully!")
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading admin panel...</p>
        </div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return null
  }

  const totalRevenue = orders.reduce((sum, order) => sum + order.amount, 0)
  const totalCustomers = new Set(orders.map((order) => order.phone)).size

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-orange-600">StoreHeer Admin</h1>
          <div className="flex items-center gap-4">
            <Button onClick={refreshOrders} variant="outline" size="sm">
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
            <Button onClick={handleLogout} variant="outline" size="sm">
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{orders.length}</div>
              <p className="text-xs text-muted-foreground">All time orders</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Revenue</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">Rs. {totalRevenue.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">Total revenue</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Products</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{products.length}</div>
              <p className="text-xs text-muted-foreground">Active products</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Reviews</CardTitle>
              <Star className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{reviews.length}</div>
              <p className="text-xs text-muted-foreground">Customer reviews</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="orders" className="space-y-4">
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="products">Products</TabsTrigger>
            <TabsTrigger value="inventory">Inventory</TabsTrigger>
            <TabsTrigger value="reviews">Reviews</TabsTrigger>
            <TabsTrigger value="promotions">Promotions</TabsTrigger>
            <TabsTrigger value="checkout">Checkout</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="orders" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Recent Orders</CardTitle>
              </CardHeader>
              <CardContent>
                {orders.length === 0 ? (
                  <div className="text-center py-8">
                    <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">No orders yet</p>
                    <p className="text-sm text-gray-400">Orders will appear here when customers place them</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left p-2">Order ID</th>
                          <th className="text-left p-2">Customer</th>
                          <th className="text-left p-2">Product</th>
                          <th className="text-left p-2">Amount</th>
                          <th className="text-left p-2">Payment</th>
                          <th className="text-left p-2">Status</th>
                          <th className="text-left p-2">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {orders.map((order) => (
                          <tr key={order.id} className="border-b">
                            <td className="p-2 font-mono text-sm">{order.id}</td>
                            <td className="p-2">
                              <div>
                                <div className="font-semibold">{order.customer}</div>
                                <div className="text-sm text-gray-600">{order.phone}</div>
                                <div className="text-xs text-gray-500">
                                  {order.address}, {order.city}
                                </div>
                              </div>
                            </td>
                            <td className="p-2">{order.product}</td>
                            <td className="p-2 font-semibold">Rs. {order.amount}</td>
                            <td className="p-2">{order.paymentMethod}</td>
                            <td className="p-2">
                              <select
                                value={order.status}
                                onChange={(e) => updateOrderStatus(order.id, e.target.value)}
                                className={`px-2 py-1 rounded-full text-xs border ${
                                  order.status === "Confirmed"
                                    ? "bg-green-100 text-green-800 border-green-200"
                                    : order.status === "Shipped"
                                      ? "bg-blue-100 text-blue-800 border-blue-200"
                                      : order.status === "Delivered"
                                        ? "bg-purple-100 text-purple-800 border-purple-200"
                                        : "bg-yellow-100 text-yellow-800 border-yellow-200"
                                }`}
                              >
                                <option value="Pending">Pending</option>
                                <option value="Confirmed">Confirmed</option>
                                <option value="Shipped">Shipped</option>
                                <option value="Delivered">Delivered</option>
                              </select>
                            </td>
                            <td className="p-2">
                              <Button size="sm" variant="outline" onClick={() => setShowOrderDetails(order)}>
                                <Eye className="w-4 h-4 mr-1" />
                                View
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="products" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Products Management</h2>
              <Button onClick={() => setShowAddProduct(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Product
              </Button>
            </div>

            {showAddProduct && (
              <Card>
                <CardHeader>
                  <CardTitle>Add New Product</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleAddProduct} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="name">Product Name *</Label>
                        <Input
                          id="name"
                          value={newProduct.name}
                          onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="sku">SKU *</Label>
                        <Input
                          id="sku"
                          value={newProduct.sku}
                          onChange={(e) => setNewProduct({ ...newProduct, sku: e.target.value })}
                          placeholder="e.g., HB001"
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="category">Category *</Label>
                        <select
                          id="category"
                          value={newProduct.category}
                          onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
                          className="w-full p-2 border rounded-md"
                          required
                        >
                          <option value="">Select Category</option>
                          <option value="Handbags">Handbags</option>
                          <option value="Crossbody">Crossbody</option>
                          <option value="Shoulder Bags">Shoulder Bags</option>
                          <option value="Accessories">Accessories</option>
                          <option value="Business">Business</option>
                          <option value="Backpacks">Backpacks</option>
                        </select>
                      </div>
                      <div>
                        <Label htmlFor="price">Sale Price *</Label>
                        <Input
                          id="price"
                          type="number"
                          value={newProduct.price}
                          onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="originalPrice">Original Price *</Label>
                        <Input
                          id="originalPrice"
                          type="number"
                          value={newProduct.originalPrice}
                          onChange={(e) => setNewProduct({ ...newProduct, originalPrice: e.target.value })}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="stock">Stock Quantity *</Label>
                        <Input
                          id="stock"
                          type="number"
                          value={newProduct.stock}
                          onChange={(e) => setNewProduct({ ...newProduct, stock: e.target.value })}
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="colors">Available Colors (comma separated)</Label>
                      <Input
                        id="colors"
                        value={newProduct.colors}
                        onChange={(e) => setNewProduct({ ...newProduct, colors: e.target.value })}
                        placeholder="Black, Brown, Red, White"
                      />
                    </div>

                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        value={newProduct.description}
                        onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                        rows={3}
                      />
                    </div>

                    <div>
                      <Label htmlFor="features">Features (one per line)</Label>
                      <Textarea
                        id="features"
                        value={newProduct.features}
                        onChange={(e) => setNewProduct({ ...newProduct, features: e.target.value })}
                        placeholder="Premium leather material&#10;Multiple compartments&#10;Adjustable strap"
                        rows={4}
                      />
                    </div>

                    {/* Image Upload */}
                    <div>
                      <Label htmlFor="images">Product Images</Label>
                      <div className="border-2 border-dashed border-gray-300 rounded-lg p-4">
                        <input
                          type="file"
                          id="images"
                          multiple
                          accept="image/*"
                          onChange={(e) => handleImageUpload(e)}
                          className="hidden"
                        />
                        <label htmlFor="images" className="cursor-pointer">
                          <div className="text-center">
                            <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                            <p className="text-sm text-gray-600">Click to upload images</p>
                          </div>
                        </label>
                      </div>

                      {/* Image Preview */}
                      {newProduct.images.length > 0 && (
                        <div className="grid grid-cols-4 gap-2 mt-4">
                          {newProduct.images.map((image, index) => (
                            <div key={index} className="relative">
                              <img
                                src={image || "/placeholder.svg"}
                                alt={`Product ${index + 1}`}
                                className="w-full h-20 object-cover rounded border"
                              />
                              <button
                                type="button"
                                onClick={() => removeImage(index)}
                                className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs"
                              >
                                ×
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    <div className="flex gap-2">
                      <Button type="submit">Add Product</Button>
                      <Button type="button" variant="outline" onClick={() => setShowAddProduct(false)}>
                        Cancel
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            )}

            {editingProduct && (
              <Card>
                <CardHeader>
                  <CardTitle>Edit Product</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleUpdateProduct} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="edit-name">Product Name</Label>
                        <Input
                          id="edit-name"
                          value={editingProduct.name}
                          onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="edit-sku">SKU</Label>
                        <Input
                          id="edit-sku"
                          value={editingProduct.sku}
                          onChange={(e) => setEditingProduct({ ...editingProduct, sku: e.target.value })}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="edit-category">Category</Label>
                        <select
                          id="edit-category"
                          value={editingProduct.category}
                          onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value })}
                          className="w-full p-2 border rounded-md"
                        >
                          <option value="Handbags">Handbags</option>
                          <option value="Crossbody">Crossbody</option>
                          <option value="Shoulder Bags">Shoulder Bags</option>
                          <option value="Accessories">Accessories</option>
                          <option value="Business">Business</option>
                          <option value="Backpacks">Backpacks</option>
                        </select>
                      </div>
                      <div>
                        <Label htmlFor="edit-price">Sale Price</Label>
                        <Input
                          id="edit-price"
                          type="number"
                          value={editingProduct.price}
                          onChange={(e) =>
                            setEditingProduct({ ...editingProduct, price: Number.parseInt(e.target.value) })
                          }
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="edit-originalPrice">Original Price</Label>
                        <Input
                          id="edit-originalPrice"
                          type="number"
                          value={editingProduct.originalPrice}
                          onChange={(e) =>
                            setEditingProduct({ ...editingProduct, originalPrice: Number.parseInt(e.target.value) })
                          }
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="edit-stock">Stock Quantity</Label>
                        <Input
                          id="edit-stock"
                          type="number"
                          value={editingProduct.stock}
                          onChange={(e) =>
                            setEditingProduct({ ...editingProduct, stock: Number.parseInt(e.target.value) })
                          }
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="edit-colors">Available Colors</Label>
                      <Input
                        id="edit-colors"
                        value={editingProduct.colors}
                        onChange={(e) => setEditingProduct({ ...editingProduct, colors: e.target.value })}
                      />
                    </div>

                    <div>
                      <Label htmlFor="edit-description">Description</Label>
                      <Textarea
                        id="edit-description"
                        value={editingProduct.description}
                        onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                        rows={3}
                      />
                    </div>

                    <div>
                      <Label htmlFor="edit-features">Features (one per line)</Label>
                      <Textarea
                        id="edit-features"
                        value={editingProduct.features}
                        onChange={(e) => setEditingProduct({ ...editingProduct, features: e.target.value })}
                        rows={4}
                      />
                    </div>

                    {/* Image Management */}
                    <div>
                      <Label>Product Images</Label>
                      <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 mb-4">
                        <input
                          type="file"
                          id="edit-images"
                          multiple
                          accept="image/*"
                          onChange={(e) => handleImageUpload(e, true)}
                          className="hidden"
                        />
                        <label htmlFor="edit-images" className="cursor-pointer">
                          <div className="text-center">
                            <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                            <p className="text-sm text-gray-600">Click to add more images</p>
                          </div>
                        </label>
                      </div>

                      {editingProduct.images.length > 0 && (
                        <div className="grid grid-cols-4 gap-2">
                          {editingProduct.images.map((image, index) => (
                            <div key={index} className="relative">
                              <img
                                src={image || "/placeholder.svg"}
                                alt={`Product ${index + 1}`}
                                className="w-full h-20 object-cover rounded border"
                              />
                              <button
                                type="button"
                                onClick={() => removeImage(index, true)}
                                className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs"
                              >
                                ×
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    <div className="flex gap-2">
                      <Button type="submit">
                        <Save className="w-4 h-4 mr-2" />
                        Update Product
                      </Button>
                      <Button type="button" variant="outline" onClick={() => setEditingProduct(null)}>
                        Cancel
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-4">Product</th>
                        <th className="text-left p-4">SKU</th>
                        <th className="text-left p-4">Category</th>
                        <th className="text-left p-4">Price</th>
                        <th className="text-left p-4">Stock</th>
                        <th className="text-left p-4">Rating</th>
                        <th className="text-left p-4">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {products.map((product) => (
                        <tr key={product.id} className="border-b">
                          <td className="p-4">
                            <div className="flex items-center gap-3">
                              {product.images.length > 0 && (
                                <img
                                  src={product.images[0] || "/placeholder.svg"}
                                  alt={product.name}
                                  className="w-12 h-12 object-cover rounded"
                                />
                              )}
                              <div>
                                <div className="font-semibold">{product.name}</div>
                                <div className="text-sm text-gray-600">{product.description}</div>
                              </div>
                            </div>
                          </td>
                          <td className="p-4 font-mono text-sm">{product.sku}</td>
                          <td className="p-4">{product.category}</td>
                          <td className="p-4">
                            <div>
                              <span className="font-semibold">Rs. {product.price}</span>
                              <span className="text-sm text-gray-500 line-through ml-2">
                                Rs. {product.originalPrice}
                              </span>
                            </div>
                          </td>
                          <td className="p-4">
                            <span
                              className={`px-2 py-1 rounded-full text-xs ${
                                product.stock > 10
                                  ? "bg-green-100 text-green-800"
                                  : product.stock > 0
                                    ? "bg-yellow-100 text-yellow-800"
                                    : "bg-red-100 text-red-800"
                              }`}
                            >
                              {product.stock} units
                            </span>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center gap-1">
                              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                              <span>{product.rating}</span>
                              <span className="text-sm text-gray-500">({product.reviews})</span>
                            </div>
                          </td>
                          <td className="p-4">
                            <div className="flex gap-2">
                              <Button size="sm" variant="outline" onClick={() => handleEditProduct(product)}>
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button size="sm" variant="outline" onClick={() => handleDeleteProduct(product.id)}>
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="inventory" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Inventory Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {products.map((product) => (
                    <div key={product.id} className="border rounded-lg p-4">
                      <div className="flex items-center gap-3 mb-3">
                        {product.images.length > 0 && (
                          <img
                            src={product.images[0] || "/placeholder.svg"}
                            alt={product.name}
                            className="w-16 h-16 object-cover rounded"
                          />
                        )}
                        <div>
                          <h3 className="font-semibold">{product.name}</h3>
                          <p className="text-sm text-gray-600">SKU: {product.sku}</p>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span>Current Stock:</span>
                          <span
                            className={`font-semibold ${
                              product.stock > 10
                                ? "text-green-600"
                                : product.stock > 0
                                  ? "text-yellow-600"
                                  : "text-red-600"
                            }`}
                          >
                            {product.stock} units
                          </span>
                        </div>

                        <div className="flex justify-between">
                          <span>Available Colors:</span>
                          <div className="flex gap-1">
                            {product.colors.map((color, index) => (
                              <span key={index} className="px-2 py-1 bg-gray-100 rounded text-xs">
                                {color}
                              </span>
                            ))}
                          </div>
                        </div>

                        <div className="flex gap-2 mt-4">
                          <Input
                            type="number"
                            placeholder="Add stock"
                            className="flex-1"
                            onKeyPress={(e) => {
                              if (e.key === "Enter") {
                                const input = e.target as HTMLInputElement
                                const addStock = Number.parseInt(input.value)
                                if (addStock > 0) {
                                  setProducts(
                                    products.map((p) =>
                                      p.id === product.id ? { ...p, stock: p.stock + addStock } : p,
                                    ),
                                  )
                                  input.value = ""
                                  alert(`Added ${addStock} units to ${product.name}`)
                                }
                              }
                            }}
                          />
                          <Button size="sm" variant="outline">
                            <Plus className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reviews" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Reviews Management</h2>
              <Button onClick={() => setShowAddReview(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Review
              </Button>
            </div>

            {showAddReview && (
              <Card>
                <CardHeader>
                  <CardTitle>Add New Review</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleAddReview} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="review-product">Product</Label>
                        <select
                          id="review-product"
                          value={selectedProductForReview || ""}
                          onChange={(e) => setSelectedProductForReview(Number.parseInt(e.target.value))}
                          className="w-full p-2 border rounded-md"
                          required
                        >
                          <option value="">Select Product</option>
                          {products.map((product) => (
                            <option key={product.id} value={product.id}>
                              {product.name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <Label htmlFor="review-customer">Customer Name</Label>
                        <Input
                          id="review-customer"
                          value={newReview.customerName}
                          onChange={(e) => setNewReview({ ...newReview, customerName: e.target.value })}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="review-rating">Rating</Label>
                        <select
                          id="review-rating"
                          value={newReview.rating}
                          onChange={(e) => setNewReview({ ...newReview, rating: Number.parseInt(e.target.value) })}
                          className="w-full p-2 border rounded-md"
                        >
                          <option value={5}>5 Stars</option>
                          <option value={4}>4 Stars</option>
                          <option value={3}>3 Stars</option>
                          <option value={2}>2 Stars</option>
                          <option value={1}>1 Star</option>
                        </select>
                      </div>
                      <div>
                        <Label>
                          <input
                            type="checkbox"
                            checked={newReview.verified}
                            onChange={(e) => setNewReview({ ...newReview, verified: e.target.checked })}
                            className="mr-2"
                          />
                          Verified Purchase
                        </Label>
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="review-comment">Review Comment</Label>
                      <Textarea
                        id="review-comment"
                        value={newReview.comment}
                        onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                        rows={3}
                        required
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button type="submit">Add Review</Button>
                      <Button type="button" variant="outline" onClick={() => setShowAddReview(false)}>
                        Cancel
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-4">Product</th>
                        <th className="text-left p-4">Customer</th>
                        <th className="text-left p-4">Rating</th>
                        <th className="text-left p-4">Comment</th>
                        <th className="text-left p-4">Date</th>
                        <th className="text-left p-4">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {reviews.map((review) => {
                        const product = products.find((p) => p.id === review.productId)
                        return (
                          <tr key={review.id} className="border-b">
                            <td className="p-4">
                              <div className="font-semibold">{product?.name}</div>
                              <div className="text-sm text-gray-600">SKU: {product?.sku}</div>
                            </td>
                            <td className="p-4">
                              <div className="flex items-center gap-2">
                                <span>{review.customerName}</span>
                                {review.verified && (
                                  <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">
                                    Verified
                                  </span>
                                )}
                              </div>
                            </td>
                            <td className="p-4">
                              <div className="flex items-center gap-1">
                                {[...Array(5)].map((_, i) => (
                                  <Star
                                    key={i}
                                    className={`w-4 h-4 ${
                                      i < review.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                                    }`}
                                  />
                                ))}
                                <span className="ml-1">{review.rating}</span>
                              </div>
                            </td>
                            <td className="p-4 max-w-xs">
                              <p className="text-sm truncate">{review.comment}</p>
                            </td>
                            <td className="p-4 text-sm text-gray-600">{review.date}</td>
                            <td className="p-4">
                              <Button size="sm" variant="outline" onClick={() => deleteReview(review.id)}>
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="promotions" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Sales Promotions */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="w-5 h-5" />
                    Sales Promotions
                  </CardTitle>
                  <Button onClick={() => setShowAddPromotion(true)} size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Promotion
                  </Button>
                </CardHeader>
                <CardContent className="space-y-4">
                  {showAddPromotion && (
                    <div className="border rounded-lg p-4 bg-gray-50">
                      <form onSubmit={handleAddPromotion} className="space-y-3">
                        <div>
                          <Label htmlFor="promotion-title">Promotion Title</Label>
                          <Input
                            id="promotion-title"
                            value={newPromotion.title}
                            onChange={(e) => setNewPromotion({ ...newPromotion, title: e.target.value })}
                            placeholder="PAYDAY SALE"
                            required
                          />
                        </div>
                        <div>
                          <Label htmlFor="promotion-description">Description</Label>
                          <Input
                            id="promotion-description"
                            value={newPromotion.description}
                            onChange={(e) => setNewPromotion({ ...newPromotion, description: e.target.value })}
                            placeholder="80% off on all products"
                            required
                          />
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <div>
                            <Label htmlFor="promotion-discount">Discount %</Label>
                            <Input
                              id="promotion-discount"
                              type="number"
                              value={newPromotion.discountPercentage}
                              onChange={(e) => setNewPromotion({ ...newPromotion, discountPercentage: e.target.value })}
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="promotion-start">Start Date</Label>
                            <Input
                              id="promotion-start"
                              type="date"
                              value={newPromotion.startDate}
                              onChange={(e) => setNewPromotion({ ...newPromotion, startDate: e.target.value })}
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="promotion-end">End Date</Label>
                            <Input
                              id="promotion-end"
                              type="date"
                              value={newPromotion.endDate}
                              onChange={(e) => setNewPromotion({ ...newPromotion, endDate: e.target.value })}
                              required
                            />
                          </div>
                        </div>
                        <div>
                          <Label>
                            <input
                              type="checkbox"
                              checked={newPromotion.timerEnabled}
                              onChange={(e) => setNewPromotion({ ...newPromotion, timerEnabled: e.target.checked })}
                              className="mr-2"
                            />
                            Enable Countdown Timer
                          </Label>
                        </div>
                        <div className="flex gap-2">
                          <Button type="submit" size="sm">
                            Add Promotion
                          </Button>
                          <Button type="button" variant="outline" size="sm" onClick={() => setShowAddPromotion(false)}>
                            Cancel
                          </Button>
                        </div>
                      </form>
                    </div>
                  )}

                  <div className="space-y-3">
                    {salesPromotions.map((promotion) => (
                      <div key={promotion.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold">{promotion.title}</h4>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" onClick={() => togglePromotionStatus(promotion.id)}>
                              {promotion.active ? "Deactivate" : "Activate"}
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => deletePromotion(promotion.id)}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{promotion.description}</p>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="font-semibold">Discount:</span> {promotion.discountPercentage}%
                          </div>
                          <div>
                            <span className="font-semibold">Timer:</span>{" "}
                            {promotion.timerEnabled ? "Enabled" : "Disabled"}
                          </div>
                          <div>
                            <span className="font-semibold">Start:</span> {promotion.startDate}
                          </div>
                          <div>
                            <span className="font-semibold">End:</span> {promotion.endDate}
                          </div>
                        </div>
                        <div className="mt-2">
                          <span
                            className={`px-2 py-1 rounded-full text-xs ${
                              promotion.active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                            }`}
                          >
                            {promotion.active ? "Active" : "Inactive"}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Promo Codes */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Tag className="w-5 h-5" />
                    Promo Codes
                  </CardTitle>
                  <Button onClick={() => setShowAddPromo(true)} size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Promo
                  </Button>
                </CardHeader>
                <CardContent className="space-y-4">
                  {showAddPromo && (
                    <div className="border rounded-lg p-4 bg-gray-50">
                      <form onSubmit={handleAddPromo} className="space-y-3">
                        <div>
                          <Label htmlFor="promo-code">Promo Code</Label>
                          <Input
                            id="promo-code"
                            value={newPromo.code}
                            onChange={(e) => setNewPromo({ ...newPromo, code: e.target.value })}
                            placeholder="SAVE20"
                            required
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <Label htmlFor="promo-discount">Discount</Label>
                            <Input
                              id="promo-discount"
                              type="number"
                              value={newPromo.discount}
                              onChange={(e) => setNewPromo({ ...newPromo, discount: e.target.value })}
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="promo-type">Type</Label>
                            <select
                              id="promo-type"
                              value={newPromo.type}
                              onChange={(e) =>
                                setNewPromo({ ...newPromo, type: e.target.value as "percentage" | "fixed" })
                              }
                              className="w-full p-2 border rounded-md"
                            >
                              <option value="percentage">Percentage (%)</option>
                              <option value="fixed">Fixed Amount (Rs.)</option>
                            </select>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <Label htmlFor="promo-expiry">Expiry Date</Label>
                            <Input
                              id="promo-expiry"
                              type="date"
                              value={newPromo.expiryDate}
                              onChange={(e) => setNewPromo({ ...newPromo, expiryDate: e.target.value })}
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="promo-limit">Usage Limit</Label>
                            <Input
                              id="promo-limit"
                              type="number"
                              value={newPromo.usageLimit}
                              onChange={(e) => setNewPromo({ ...newPromo, usageLimit: e.target.value })}
                              required
                            />
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button type="submit" size="sm">
                            Add Promo
                          </Button>
                          <Button type="button" variant="outline" size="sm" onClick={() => setShowAddPromo(false)}>
                            Cancel
                          </Button>
                        </div>
                      </form>
                    </div>
                  )}

                  <div className="space-y-3">
                    {promoCodes.map((promo) => (
                      <div key={promo.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold">{promo.code}</h4>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" onClick={() => togglePromoStatus(promo.id)}>
                              {promo.active ? "Deactivate" : "Activate"}
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => deletePromo(promo.id)}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="font-semibold">Discount:</span> {promo.discount}
                            {promo.type === "percentage" ? "%" : " Rs."}
                          </div>
                          <div>
                            <span className="font-semibold">Expiry:</span> {promo.expiryDate}
                          </div>
                          <div>
                            <span className="font-semibold">Usage:</span> {promo.usedCount}/{promo.usageLimit}
                          </div>
                          <div>
                            <span
                              className={`px-2 py-1 rounded-full text-xs ${
                                promo.active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                              }`}
                            >
                              {promo.active ? "Active" : "Inactive"}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="checkout" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Payment Methods */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="w-5 h-5" />
                    Payment Methods
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <input
                          type="checkbox"
                          id="jazzcash-enabled"
                          checked={checkoutSettings.jazzcashEnabled}
                          onChange={(e) =>
                            setCheckoutSettings({ ...checkoutSettings, jazzcashEnabled: e.target.checked })
                          }
                        />
                        <Label htmlFor="jazzcash-enabled" className="font-semibold">
                          JazzCash
                        </Label>
                      </div>
                      <div className="flex items-center gap-2">
                        <Label>Discount:</Label>
                        <Input
                          type="number"
                          value={checkoutSettings.jazzcashDiscount}
                          onChange={(e) =>
                            setCheckoutSettings({
                              ...checkoutSettings,
                              jazzcashDiscount: Number.parseInt(e.target.value),
                            })
                          }
                          className="w-16"
                        />
                        <span>%</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <input
                          type="checkbox"
                          id="easypaisa-enabled"
                          checked={checkoutSettings.easypaisaEnabled}
                          onChange={(e) =>
                            setCheckoutSettings({ ...checkoutSettings, easypaisaEnabled: e.target.checked })
                          }
                        />
                        <Label htmlFor="easypaisa-enabled" className="font-semibold">
                          EasyPaisa
                        </Label>
                      </div>
                      <div className="flex items-center gap-2">
                        <Label>Discount:</Label>
                        <Input
                          type="number"
                          value={checkoutSettings.easypaisaDiscount}
                          onChange={(e) =>
                            setCheckoutSettings({
                              ...checkoutSettings,
                              easypaisaDiscount: Number.parseInt(e.target.value),
                            })
                          }
                          className="w-16"
                        />
                        <span>%</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <input
                          type="checkbox"
                          id="ubl-enabled"
                          checked={checkoutSettings.ublEnabled}
                          onChange={(e) => setCheckoutSettings({ ...checkoutSettings, ublEnabled: e.target.checked })}
                        />
                        <Label htmlFor="ubl-enabled" className="font-semibold">
                          UBL Bank Transfer
                        </Label>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <input
                          type="checkbox"
                          id="cod-enabled"
                          checked={checkoutSettings.codEnabled}
                          onChange={(e) => setCheckoutSettings({ ...checkoutSettings, codEnabled: e.target.checked })}
                        />
                        <Label htmlFor="cod-enabled" className="font-semibold">
                          Cash on Delivery
                        </Label>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Shipping Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Package className="w-5 h-5" />
                    Shipping Settings
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      id="free-shipping"
                      checked={checkoutSettings.freeShipping}
                      onChange={(e) => setCheckoutSettings({ ...checkoutSettings, freeShipping: e.target.checked })}
                    />
                    <Label htmlFor="free-shipping">Enable Free Shipping</Label>
                  </div>

                  {!checkoutSettings.freeShipping && (
                    <div>
                      <Label htmlFor="shipping-cost">Shipping Cost (Rs.)</Label>
                      <Input
                        id="shipping-cost"
                        type="number"
                        value={checkoutSettings.shippingCost}
                        onChange={(e) =>
                          setCheckoutSettings({ ...checkoutSettings, shippingCost: Number.parseInt(e.target.value) })
                        }
                      />
                    </div>
                  )}

                  <div>
                    <Label htmlFor="shipping-message">Shipping Message</Label>
                    <Input
                      id="shipping-message"
                      value={checkoutSettings.shippingMessage}
                      onChange={(e) => setCheckoutSettings({ ...checkoutSettings, shippingMessage: e.target.value })}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Form Fields */}
              <Card>
                <CardHeader>
                  <CardTitle>Required Form Fields</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      id="fullname-required"
                      checked={checkoutSettings.requiredFields.fullName}
                      onChange={(e) =>
                        setCheckoutSettings({
                          ...checkoutSettings,
                          requiredFields: { ...checkoutSettings.requiredFields, fullName: e.target.checked },
                        })
                      }
                    />
                    <Label htmlFor="fullname-required">Full Name</Label>
                  </div>

                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      id="phone-required"
                      checked={checkoutSettings.requiredFields.phone}
                      onChange={(e) =>
                        setCheckoutSettings({
                          ...checkoutSettings,
                          requiredFields: { ...checkoutSettings.requiredFields, phone: e.target.checked },
                        })
                      }
                    />
                    <Label htmlFor="phone-required">Phone Number</Label>
                  </div>

                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      id="address-required"
                      checked={checkoutSettings.requiredFields.address}
                      onChange={(e) =>
                        setCheckoutSettings({
                          ...checkoutSettings,
                          requiredFields: { ...checkoutSettings.requiredFields, address: e.target.checked },
                        })
                      }
                    />
                    <Label htmlFor="address-required">Complete Address</Label>
                  </div>

                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      id="city-required"
                      checked={checkoutSettings.requiredFields.city}
                      onChange={(e) =>
                        setCheckoutSettings({
                          ...checkoutSettings,
                          requiredFields: { ...checkoutSettings.requiredFields, city: e.target.checked },
                        })
                      }
                    />
                    <Label htmlFor="city-required">City</Label>
                  </div>
                </CardContent>
              </Card>

              {/* Province Options */}
              <Card>
                <CardHeader>
                  <CardTitle>Province Options</CardTitle>
                </CardHeader>
                <CardContent>
                  <div>
                    <Label htmlFor="provinces">Available Provinces (one per line)</Label>
                    <Textarea
                      id="provinces"
                      value={checkoutSettings.provinces.join("\n")}
                      onChange={(e) =>
                        setCheckoutSettings({
                          ...checkoutSettings,
                          provinces: e.target.value.split("\n").filter((p) => p.trim()),
                        })
                      }
                      rows={7}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Payment Instructions */}
            <Card>
              <CardHeader>
                <CardTitle>Payment Instructions</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="jazzcash-inst" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="jazzcash-inst">JazzCash</TabsTrigger>
                    <TabsTrigger value="easypaisa-inst">EasyPaisa</TabsTrigger>
                    <TabsTrigger value="ubl-inst">UBL Bank</TabsTrigger>
                  </TabsList>

                  <TabsContent value="jazzcash-inst" className="space-y-3">
                    <Label>JazzCash Payment Instructions (one per line)</Label>
                    <Textarea
                      value={checkoutSettings.jazzcashInstructions.join("\n")}
                      onChange={(e) =>
                        setCheckoutSettings({
                          ...checkoutSettings,
                          jazzcashInstructions: e.target.value.split("\n").filter((i) => i.trim()),
                        })
                      }
                      rows={6}
                    />
                    <p className="text-sm text-gray-600">Use {`{amount}`} to display the order amount dynamically</p>
                  </TabsContent>

                  <TabsContent value="easypaisa-inst" className="space-y-3">
                    <Label>EasyPaisa Payment Instructions (one per line)</Label>
                    <Textarea
                      value={checkoutSettings.easypaisaInstructions.join("\n")}
                      onChange={(e) =>
                        setCheckoutSettings({
                          ...checkoutSettings,
                          easypaisaInstructions: e.target.value.split("\n").filter((i) => i.trim()),
                        })
                      }
                      rows={6}
                    />
                    <p className="text-sm text-gray-600">Use {`{amount}`} to display the order amount dynamically</p>
                  </TabsContent>

                  <TabsContent value="ubl-inst" className="space-y-3">
                    <Label>UBL Bank Transfer Instructions (one per line)</Label>
                    <Textarea
                      value={checkoutSettings.ublInstructions.join("\n")}
                      onChange={(e) =>
                        setCheckoutSettings({
                          ...checkoutSettings,
                          ublInstructions: e.target.value.split("\n").filter((i) => i.trim()),
                        })
                      }
                      rows={6}
                    />
                    <p className="text-sm text-gray-600">Use {`{amount}`} to display the order amount dynamically</p>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            {/* Order Confirmation Messages */}
            <Card>
              <CardHeader>
                <CardTitle>Order Confirmation Messages</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="success-message">Success Message (Online Payments)</Label>
                  <Textarea
                    id="success-message"
                    value={checkoutSettings.successMessage}
                    onChange={(e) => setCheckoutSettings({ ...checkoutSettings, successMessage: e.target.value })}
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="cod-message">COD Confirmation Message</Label>
                  <Textarea
                    id="cod-message"
                    value={checkoutSettings.codMessage}
                    onChange={(e) => setCheckoutSettings({ ...checkoutSettings, codMessage: e.target.value })}
                    rows={3}
                  />
                  <p className="text-sm text-gray-600 mt-1">Use {`{amount}`} to display the order amount dynamically</p>
                </div>
              </CardContent>
            </Card>

            {/* Save Button */}
            <div className="flex justify-end">
              <Button onClick={handleUpdateCheckoutSettings} className="bg-gradient-to-r from-green-500 to-green-600">
                <Save className="w-4 h-4 mr-2" />
                Save Checkout Settings
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Payment Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="jazzcash">JazzCash Account</Label>
                  <Input
                    id="jazzcash"
                    value={paymentSettings.jazzcash}
                    onChange={(e) => setPaymentSettings({ ...paymentSettings, jazzcash: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="easypaisa">EasyPaisa Account</Label>
                  <Input
                    id="easypaisa"
                    value={paymentSettings.easypaisa}
                    onChange={(e) => setPaymentSettings({ ...paymentSettings, easypaisa: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="ubl">UBL Bank Account</Label>
                  <Input
                    id="ubl"
                    value={paymentSettings.ubl}
                    onChange={(e) => setPaymentSettings({ ...paymentSettings, ubl: e.target.value })}
                  />
                </div>
                <Button onClick={handleUpdatePaymentSettings}>
                  <Save className="w-4 h-4 mr-2" />
                  Update Payment Settings
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Order Details Modal */}
      {showOrderDetails && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="text-lg font-semibold">Order Details</h2>
              <button onClick={() => setShowOrderDetails(null)} className="p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="font-semibold text-gray-800">Order Information</h3>
                  <p>
                    <strong>Order ID:</strong> {showOrderDetails.id}
                  </p>
                  <p>
                    <strong>Date:</strong> {showOrderDetails.date}
                  </p>
                  <p>
                    <strong>Status:</strong>
                    <span
                      className={`ml-2 px-2 py-1 rounded-full text-xs ${
                        showOrderDetails.status === "Confirmed"
                          ? "bg-green-100 text-green-800"
                          : showOrderDetails.status === "Shipped"
                            ? "bg-blue-100 text-blue-800"
                            : showOrderDetails.status === "Delivered"
                              ? "bg-purple-100 text-purple-800"
                              : "bg-yellow-100 text-yellow-800"
                      }`}
                    >
                      {showOrderDetails.status}
                    </span>
                  </p>
                </div>

                <div>
                  <h3 className="font-semibold text-gray-800">Customer Information</h3>
                  <p>
                    <strong>Name:</strong> {showOrderDetails.customer}
                  </p>
                  <p>
                    <strong>Phone:</strong> {showOrderDetails.phone}
                  </p>
                  <p>
                    <strong>Address:</strong> {showOrderDetails.address}
                  </p>
                  <p>
                    <strong>City:</strong> {showOrderDetails.city}, {showOrderDetails.province}
                  </p>
                </div>
              </div>

              <div>
                <h3 className="font-semibold text-gray-800">Product Information</h3>
                <p>
                  <strong>Product:</strong> {showOrderDetails.product}
                </p>
                <p>
                  <strong>Amount:</strong> Rs. {showOrderDetails.amount}
                </p>
                <p>
                  <strong>Payment Method:</strong> {showOrderDetails.paymentMethod}
                </p>
                {showOrderDetails.transactionId && (
                  <p>
                    <strong>Transaction ID:</strong> {showOrderDetails.transactionId}
                  </p>
                )}
              </div>

              <div className="flex gap-2 pt-4">
                <select
                  value={showOrderDetails.status}
                  onChange={(e) => {
                    updateOrderStatus(showOrderDetails.id, e.target.value)
                    setShowOrderDetails({ ...showOrderDetails, status: e.target.value })
                  }}
                  className="px-3 py-2 border rounded-md"
                >
                  <option value="Pending">Pending</option>
                  <option value="Confirmed">Confirmed</option>
                  <option value="Shipped">Shipped</option>
                  <option value="Delivered">Delivered</option>
                </select>
                <Button onClick={() => setShowOrderDetails(null)}>Close</Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
