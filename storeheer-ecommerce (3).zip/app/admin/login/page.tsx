"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Lock, Eye, EyeOff, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function AdminLogin() {
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const [showForgotPassword, setShowForgotPassword] = useState(false)
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    // Simple password check (in production, use proper authentication)
    if (password === "storeheer2025") {
      // Set admin session
      localStorage.setItem("admin-authenticated", "true")
      localStorage.setItem("admin-login-time", Date.now().toString())
      router.push("/admin")
    } else {
      setError("Invalid password. Please try again.")
    }

    setLoading(false)
  }

  const handleForgotPassword = () => {
    setShowForgotPassword(true)
    // Send email to admin
    window.location.href =
      "mailto:theheer@gmail.com?subject=Admin Password Recovery Request&body=Hello, I need help recovering my admin password for StoreHeer website. Please assist me with password recovery."
  }

  if (showForgotPassword) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-2xl p-8 w-full max-w-md">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Mail className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">Password Recovery</h1>
            <p className="text-gray-600">We've opened your email client to contact the administrator</p>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <h3 className="font-semibold text-blue-800 mb-2">Contact Administrator</h3>
            <p className="text-blue-700 text-sm mb-3">
              Please send an email to the system administrator for password recovery assistance.
            </p>
            <div className="bg-white rounded p-3 border">
              <p className="text-sm font-mono text-gray-800">theheer@gmail.com</p>
            </div>
          </div>

          <div className="space-y-3">
            <Button
              onClick={handleForgotPassword}
              className="w-full bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700 text-white font-semibold py-3"
            >
              <Mail className="w-4 h-4 mr-2" />
              Send Recovery Email
            </Button>

            <Button onClick={() => setShowForgotPassword(false)} variant="outline" className="w-full">
              Back to Login
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl p-8 w-full max-w-md">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Lock className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Admin Login</h1>
          <p className="text-gray-600">Enter your password to access the admin panel</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <Label htmlFor="password">Admin Password</Label>
            <div className="relative">
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-10 pr-10 border-2 border-gray-200 focus:border-orange-500"
                placeholder="Enter admin password"
                required
              />
              <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2"
              >
                {showPassword ? (
                  <EyeOff className="w-4 h-4 text-gray-400" />
                ) : (
                  <Eye className="w-4 h-4 text-gray-400" />
                )}
              </button>
            </div>
          </div>

          {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">{error}</div>}

          <Button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white font-semibold py-3"
          >
            {loading ? "Logging in..." : "Login to Admin Panel"}
          </Button>
        </form>

        <div className="mt-6 text-center">
          <button
            onClick={() => setShowForgotPassword(true)}
            className="text-sm text-orange-600 hover:text-orange-700 hover:underline"
          >
            Forgot password? Contact system administrator.
          </button>
        </div>
      </div>
    </div>
  )
}
