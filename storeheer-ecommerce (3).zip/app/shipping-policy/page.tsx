import Header from "@/components/Header"
import Footer from "@/components/Footer"
import PolicyLayout from "@/components/PolicyLayout"

export default function ShippingPolicyPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <PolicyLayout title="Shipping Policy">
        <div className="space-y-6">
          <section>
            <h2 className="text-2xl font-semibold mb-4">Free Delivery All Over Pakistan</h2>
            <p className="text-gray-600 mb-4">
              We offer free home delivery across Pakistan for all orders. Your satisfaction is our priority, and we
              ensure safe and timely delivery of your products.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Delivery Areas</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="font-semibold text-green-800 mb-2">Major Cities (1-2 Days)</h4>
                <ul className="text-green-700 space-y-1">
                  <li>• Karachi</li>
                  <li>• Lahore</li>
                  <li>• Islamabad</li>
                  <li>• Rawalpindi</li>
                  <li>• Faisalabad</li>
                  <li>• Multan</li>
                </ul>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold text-blue-800 mb-2">Other Cities (2-4 Days)</h4>
                <ul className="text-blue-700 space-y-1">
                  <li>• Peshawar</li>
                  <li>• Quetta</li>
                  <li>• Sialkot</li>
                  <li>• Gujranwala</li>
                  <li>• Sargodha</li>
                  <li>• All other cities</li>
                </ul>
              </div>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Delivery Process</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-orange-600 font-semibold">1</span>
                </div>
                <div>
                  <h4 className="font-semibold">Order Confirmation</h4>
                  <p className="text-gray-600">
                    After placing your order, you'll receive a confirmation call within 2-4 hours to verify your
                    details.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-orange-600 font-semibold">2</span>
                </div>
                <div>
                  <h4 className="font-semibold">Processing</h4>
                  <p className="text-gray-600">
                    Your order is processed and prepared for shipment within 24 hours of confirmation.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-orange-600 font-semibold">3</span>
                </div>
                <div>
                  <h4 className="font-semibold">Dispatch</h4>
                  <p className="text-gray-600">
                    Your order is dispatched via our trusted courier partners with tracking information.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-orange-600 font-semibold">4</span>
                </div>
                <div>
                  <h4 className="font-semibold">Delivery</h4>
                  <p className="text-gray-600">
                    Our courier will contact you before delivery and hand over your package safely.
                  </p>
                </div>
              </div>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Delivery Partners</h3>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-gray-600 mb-2">We work with trusted courier services including:</p>
              <ul className="list-disc list-inside text-gray-600 space-y-1">
                <li>TCS (Tranzum Courier Services)</li>
                <li>Leopards Courier</li>
                <li>M&P Express</li>
                <li>Call Courier</li>
                <li>Blue-Ex</li>
              </ul>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Order Tracking</h3>
            <p className="text-gray-600 mb-4">Once your order is dispatched, you'll receive:</p>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>SMS with tracking number and courier details</li>
              <li>WhatsApp message with tracking link</li>
              <li>Email with complete delivery information</li>
              <li>Real-time updates on delivery status</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Delivery Charges</h3>
            <div className="bg-green-50 p-6 rounded-lg">
              <h4 className="font-semibold text-green-800 text-xl mb-2">🎉 FREE DELIVERY</h4>
              <p className="text-green-700">
                We offer completely free home delivery across Pakistan for all orders. No minimum order value required!
              </p>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Special Instructions</h3>
            <div className="space-y-4">
              <div className="bg-yellow-50 p-4 rounded-lg">
                <h4 className="font-semibold text-yellow-800">Cash on Delivery (COD)</h4>
                <p className="text-yellow-700">Please keep the exact amount ready for COD orders to avoid delays.</p>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold text-blue-800">Address Accuracy</h4>
                <p className="text-blue-700">
                  Please provide complete and accurate address details including landmarks for smooth delivery.
                </p>
              </div>

              <div className="bg-purple-50 p-4 rounded-lg">
                <h4 className="font-semibold text-purple-800">Availability</h4>
                <p className="text-purple-700">
                  Please ensure someone is available at the delivery address during business hours.
                </p>
              </div>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Delivery Issues</h3>
            <p className="text-gray-600 mb-4">If you face any delivery issues, please contact us immediately:</p>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-gray-600 mb-2">
                <strong>WhatsApp:</strong> +92 300 1234567
              </p>
              <p className="text-gray-600 mb-2">
                <strong>Phone:</strong> +92 300 1234567
              </p>
              <p className="text-gray-600">
                <strong>Email:</strong> storeheer@gmail.com
              </p>
            </div>
          </section>
        </div>
      </PolicyLayout>
      <Footer />
    </div>
  )
}
