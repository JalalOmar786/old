import Header from "@/components/Header"
import Footer from "@/components/Footer"
import PolicyLayout from "@/components/PolicyLayout"

export default function ContactInformationPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <PolicyLayout title="Contact Information">
        <div className="space-y-6">
          <section>
            <h2 className="text-2xl font-semibold mb-4">Get in Touch with StoreHeer</h2>
            <p className="text-gray-600 mb-4">
              We're here to help you with any questions, concerns, or feedback you may have. Our customer service team
              is dedicated to providing you with the best possible experience.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Contact Details</h3>
            <div className="bg-gray-50 p-6 rounded-lg space-y-4">
              <div>
                <h4 className="font-semibold text-gray-800">Email Address</h4>
                <p className="text-gray-600">storeheer@gmail.com</p>
                <p className="text-sm text-gray-500">We respond to all emails within 24 hours</p>
              </div>

              <div>
                <h4 className="font-semibold text-gray-800">Phone Number</h4>
                <p className="text-gray-600">+92 300 1234567</p>
                <p className="text-sm text-gray-500">Available Monday to Saturday, 9:00 AM - 8:00 PM (PKT)</p>
              </div>

              <div>
                <h4 className="font-semibold text-gray-800">WhatsApp Support</h4>
                <p className="text-gray-600">+92 300 1234567</p>
                <p className="text-sm text-gray-500">Quick support and instant responses</p>
              </div>

              <div>
                <h4 className="font-semibold text-gray-800">Business Address</h4>
                <p className="text-gray-600">Lahore, Punjab, Pakistan</p>
                <p className="text-sm text-gray-500">Visits by appointment only</p>
              </div>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Business Hours</h3>
            <div className="bg-blue-50 p-4 rounded-lg">
              <ul className="space-y-2">
                <li className="flex justify-between">
                  <span>Monday - Friday:</span>
                  <span className="font-semibold">9:00 AM - 8:00 PM</span>
                </li>
                <li className="flex justify-between">
                  <span>Saturday:</span>
                  <span className="font-semibold">10:00 AM - 6:00 PM</span>
                </li>
                <li className="flex justify-between">
                  <span>Sunday:</span>
                  <span className="font-semibold">Closed</span>
                </li>
              </ul>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">What We Can Help You With</h3>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>Product inquiries and recommendations</li>
              <li>Order status and tracking information</li>
              <li>Payment and billing questions</li>
              <li>Shipping and delivery concerns</li>
              <li>Returns and exchanges</li>
              <li>Technical support</li>
              <li>Feedback and suggestions</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Response Times</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="font-semibold text-green-800">WhatsApp</h4>
                <p className="text-green-700">Usually within 30 minutes during business hours</p>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold text-blue-800">Email</h4>
                <p className="text-blue-700">Within 24 hours</p>
              </div>
              <div className="bg-orange-50 p-4 rounded-lg">
                <h4 className="font-semibold text-orange-800">Phone</h4>
                <p className="text-orange-700">Immediate during business hours</p>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg">
                <h4 className="font-semibold text-purple-800">Contact Form</h4>
                <p className="text-purple-700">Within 24-48 hours</p>
              </div>
            </div>
          </section>
        </div>
      </PolicyLayout>
      <Footer />
    </div>
  )
}
