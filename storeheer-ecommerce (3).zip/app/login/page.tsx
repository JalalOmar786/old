import Header from "@/components/Header"
import Footer from "@/components/Footer"
import LoginContent from "@/components/LoginContent"

export default function LoginPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <LoginContent />
      <Footer />
    </div>
  )
}
