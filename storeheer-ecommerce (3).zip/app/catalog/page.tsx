import Header from "@/components/Header"
import Footer from "@/components/Footer"
import CatalogContent from "@/components/CatalogContent"

export default function CatalogPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <CatalogContent />
      <Footer />
    </div>
  )
}
