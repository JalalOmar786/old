import Header from "@/components/Header"
import Footer from "@/components/Footer"
import PolicyLayout from "@/components/PolicyLayout"

export default function TermsOfServicePage() {
  return (
    <div className="min-h-screen">
      <Header />
      <PolicyLayout title="Terms of Service">
        <div className="space-y-6">
          <p className="text-gray-600">
            <strong>Last updated:</strong> January 2025
          </p>

          <section>
            <h2 className="text-2xl font-semibold mb-4">Agreement to Terms</h2>
            <p className="text-gray-600 mb-4">
              By accessing and using StoreHeer's website and services, you agree to be bound by these Terms of Service
              and all applicable laws and regulations. If you do not agree with any of these terms, you are prohibited
              from using or accessing this site.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Use License</h3>
            <p className="text-gray-600 mb-4">
              Permission is granted to temporarily download one copy of StoreHeer's materials for personal,
              non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under
              this license you may not:
            </p>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>Modify or copy the materials</li>
              <li>Use the materials for any commercial purpose or for any public display</li>
              <li>Attempt to reverse engineer any software contained on the website</li>
              <li>Remove any copyright or other proprietary notations from the materials</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Product Information</h3>
            <p className="text-gray-600 mb-4">
              We strive to provide accurate product descriptions, images, and pricing. However:
            </p>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>Colors may vary slightly due to monitor settings</li>
              <li>We reserve the right to correct any errors in pricing or product information</li>
              <li>Product availability is subject to change without notice</li>
              <li>We may discontinue products at any time</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Orders and Payment</h3>
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold text-gray-800">Order Acceptance</h4>
                <p className="text-gray-600">
                  All orders are subject to acceptance and availability. We reserve the right to refuse or cancel any
                  order for any reason, including but not limited to product availability, errors in pricing, or
                  suspected fraudulent activity.
                </p>
              </div>

              <div>
                <h4 className="font-semibold text-gray-800">Payment Terms</h4>
                <ul className="list-disc list-inside text-gray-600 space-y-1">
                  <li>Payment is required at the time of order placement or delivery (COD)</li>
                  <li>We accept JazzCash, EasyPaisa, and Cash on Delivery</li>
                  <li>All prices are in Pakistani Rupees (PKR)</li>
                  <li>Prices are subject to change without notice</li>
                </ul>
              </div>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Shipping and Delivery</h3>
            <p className="text-gray-600 mb-4">
              We provide free shipping across Pakistan. Delivery times are estimates and may vary due to:
            </p>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>Weather conditions</li>
              <li>Courier service delays</li>
              <li>Remote location accessibility</li>
              <li>Public holidays and events</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Returns and Refunds</h3>
            <p className="text-gray-600 mb-4">
              Our return and refund policy is detailed in our separate Refund Policy document. By making a purchase, you
              agree to our return terms and conditions.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">User Accounts</h3>
            <p className="text-gray-600 mb-4">
              When you create an account with us, you must provide accurate and complete information. You are
              responsible for:
            </p>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>Maintaining the confidentiality of your account credentials</li>
              <li>All activities that occur under your account</li>
              <li>Notifying us immediately of any unauthorized use</li>
              <li>Ensuring your contact information is current</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Prohibited Uses</h3>
            <p className="text-gray-600 mb-4">You may not use our service:</p>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>For any unlawful purpose or to solicit others to perform unlawful acts</li>
              <li>
                To violate any international, federal, provincial, or state regulations, rules, laws, or local
                ordinances
              </li>
              <li>
                To infringe upon or violate our intellectual property rights or the intellectual property rights of
                others
              </li>
              <li>To harass, abuse, insult, harm, defame, slander, disparage, intimidate, or discriminate</li>
              <li>To submit false or misleading information</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Disclaimer</h3>
            <p className="text-gray-600 mb-4">
              The materials on StoreHeer's website are provided on an 'as is' basis. StoreHeer makes no warranties,
              expressed or implied, and hereby disclaims and negates all other warranties including without limitation,
              implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement
              of intellectual property or other violation of rights.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Limitations</h3>
            <p className="text-gray-600 mb-4">
              In no event shall StoreHeer or its suppliers be liable for any damages (including, without limitation,
              damages for loss of data or profit, or due to business interruption) arising out of the use or inability
              to use the materials on StoreHeer's website, even if StoreHeer or an authorized representative has been
              notified orally or in writing of the possibility of such damage.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Governing Law</h3>
            <p className="text-gray-600 mb-4">
              These terms and conditions are governed by and construed in accordance with the laws of Pakistan, and you
              irrevocably submit to the exclusive jurisdiction of the courts in that state or location.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Changes to Terms</h3>
            <p className="text-gray-600 mb-4">
              We reserve the right to revise these terms of service at any time without notice. By using this website,
              you are agreeing to be bound by the then current version of these terms of service.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Contact Information</h3>
            <p className="text-gray-600 mb-4">
              If you have any questions about these Terms of Service, please contact us:
            </p>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-gray-600">
                <strong>Email:</strong> storeheer@gmail.com
                <br />
                <strong>Phone:</strong> +92 300 1234567
                <br />
                <strong>WhatsApp:</strong> +92 300 1234567
              </p>
            </div>
          </section>
        </div>
      </PolicyLayout>
      <Footer />
    </div>
  )
}
