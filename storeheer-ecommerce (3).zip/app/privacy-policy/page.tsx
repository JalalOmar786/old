import Header from "@/components/Header"
import Footer from "@/components/Footer"
import PolicyLayout from "@/components/PolicyLayout"

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <PolicyLayout title="Privacy Policy">
        <div className="space-y-6">
          <p className="text-gray-600">
            <strong>Last updated:</strong> January 2025
          </p>

          <section>
            <h2 className="text-2xl font-semibold mb-4">Introduction</h2>
            <p className="text-gray-600 mb-4">
              At StoreHeer, we are committed to protecting your privacy and ensuring the security of your personal
              information. This Privacy Policy explains how we collect, use, disclose, and safeguard your information
              when you visit our website or make purchases from us.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Information We Collect</h3>
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold text-gray-800">Personal Information</h4>
                <ul className="list-disc list-inside text-gray-600 mt-2 space-y-1">
                  <li>Name and contact information (email, phone number, address)</li>
                  <li>Payment information (processed securely through our payment partners)</li>
                  <li>Order history and preferences</li>
                  <li>Account credentials (if you create an account)</li>
                </ul>
              </div>

              <div>
                <h4 className="font-semibold text-gray-800">Automatically Collected Information</h4>
                <ul className="list-disc list-inside text-gray-600 mt-2 space-y-1">
                  <li>IP address and browser information</li>
                  <li>Device information and operating system</li>
                  <li>Website usage data and analytics</li>
                  <li>Cookies and similar tracking technologies</li>
                </ul>
              </div>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">How We Use Your Information</h3>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>Process and fulfill your orders</li>
              <li>Communicate with you about your orders and account</li>
              <li>Provide customer support and respond to inquiries</li>
              <li>Send promotional emails and marketing communications (with your consent)</li>
              <li>Improve our website and services</li>
              <li>Prevent fraud and ensure security</li>
              <li>Comply with legal obligations</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Information Sharing</h3>
            <p className="text-gray-600 mb-4">
              We do not sell, trade, or rent your personal information to third parties. We may share your information
              only in the following circumstances:
            </p>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>With service providers who help us operate our business (payment processors, shipping companies)</li>
              <li>When required by law or to protect our rights</li>
              <li>In connection with a business transfer or merger</li>
              <li>With your explicit consent</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Data Security</h3>
            <p className="text-gray-600 mb-4">
              We implement appropriate technical and organizational measures to protect your personal information
              against unauthorized access, alteration, disclosure, or destruction. However, no method of transmission
              over the internet or electronic storage is 100% secure.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Your Rights</h3>
            <p className="text-gray-600 mb-4">You have the right to:</p>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>Access and update your personal information</li>
              <li>Request deletion of your personal information</li>
              <li>Opt-out of marketing communications</li>
              <li>Request a copy of your personal information</li>
              <li>Lodge a complaint with relevant authorities</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Cookies</h3>
            <p className="text-gray-600 mb-4">
              We use cookies and similar technologies to enhance your browsing experience, analyze website traffic, and
              personalize content. You can control cookie settings through your browser preferences.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Contact Us</h3>
            <p className="text-gray-600">
              If you have any questions about this Privacy Policy or our data practices, please contact us at:
            </p>
            <div className="bg-gray-50 p-4 rounded-lg mt-4">
              <p className="text-gray-600">
                <strong>Email:</strong> storeheer@gmail.com
                <br />
                <strong>Phone:</strong> +92 300 1234567
                <br />
                <strong>Address:</strong> Lahore, Punjab, Pakistan
              </p>
            </div>
          </section>
        </div>
      </PolicyLayout>
      <Footer />
    </div>
  )
}
