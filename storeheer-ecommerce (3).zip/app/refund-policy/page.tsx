import Header from "@/components/Header"
import Footer from "@/components/Footer"
import PolicyLayout from "@/components/PolicyLayout"

export default function RefundPolicyPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <PolicyLayout title="Refund Policy">
        <div className="space-y-6">
          <section>
            <h2 className="text-2xl font-semibold mb-4">100% Refund Guarantee</h2>
            <p className="text-gray-600 mb-4">
              At StoreHeer, we stand behind the quality of our products. We offer a 100% refund guarantee to ensure your
              complete satisfaction with every purchase.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Refund Eligibility</h3>
            <div className="bg-green-50 p-6 rounded-lg mb-4">
              <h4 className="font-semibold text-green-800 mb-2">You are eligible for a full refund if:</h4>
              <ul className="list-disc list-inside text-green-700 space-y-1">
                <li>The product is damaged or defective upon arrival</li>
                <li>The product doesn't match the description or photos</li>
                <li>You received the wrong item</li>
                <li>The product has manufacturing defects</li>
                <li>You're not satisfied with the quality</li>
              </ul>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Refund Process</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-orange-600 font-semibold">1</span>
                </div>
                <div>
                  <h4 className="font-semibold">Contact Us</h4>
                  <p className="text-gray-600">
                    Contact our customer service within 14 days of receiving your order via WhatsApp (+92 300 1234567)
                    or email (storeheer@gmail.com).
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-orange-600 font-semibold">2</span>
                </div>
                <div>
                  <h4 className="font-semibold">Provide Details</h4>
                  <p className="text-gray-600">
                    Share your order number, reason for return, and photos of the product (if applicable).
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-orange-600 font-semibold">3</span>
                </div>
                <div>
                  <h4 className="font-semibold">Return Authorization</h4>
                  <p className="text-gray-600">
                    We'll provide you with return instructions and a return authorization number.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-orange-600 font-semibold">4</span>
                </div>
                <div>
                  <h4 className="font-semibold">Send the Product</h4>
                  <p className="text-gray-600">Ship the product back to us in its original condition and packaging.</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-orange-600 font-semibold">5</span>
                </div>
                <div>
                  <h4 className="font-semibold">Receive Your Refund</h4>
                  <p className="text-gray-600">
                    Once we receive and inspect the product, we'll process your refund within 3-5 business days.
                  </p>
                </div>
              </div>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Refund Methods</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold text-blue-800">JazzCash/EasyPaisa</h4>
                <p className="text-blue-700">Instant refund to your mobile wallet</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="font-semibold text-green-800">Bank Transfer</h4>
                <p className="text-green-700">Direct transfer to your bank account</p>
              </div>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Important Notes</h3>
            <div className="bg-yellow-50 p-4 rounded-lg">
              <ul className="list-disc list-inside text-yellow-800 space-y-2">
                <li>Products must be returned in original condition</li>
                <li>Return shipping costs are covered by us for defective items</li>
                <li>Refunds are processed in the same currency as the original payment</li>
                <li>Custom or personalized items may have different return policies</li>
              </ul>
            </div>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Exchange Policy</h3>
            <p className="text-gray-600 mb-4">
              If you'd prefer to exchange your item for a different size or color, we're happy to accommodate. The
              exchange process follows the same steps as returns, but we'll send you the replacement item once we
              receive the original.
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold mb-3">Contact for Refunds</h3>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-gray-600 mb-2">
                <strong>WhatsApp:</strong> +92 300 1234567 (Fastest response)
              </p>
              <p className="text-gray-600 mb-2">
                <strong>Email:</strong> storeheer@gmail.com
              </p>
              <p className="text-gray-600">
                <strong>Response Time:</strong> Within 24 hours
              </p>
            </div>
          </section>
        </div>
      </PolicyLayout>
      <Footer />
    </div>
  )
}
