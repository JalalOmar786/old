import Header from "@/components/Header"
import Footer from "@/components/Footer"
import HeroSection from "@/components/HeroSection"
import FeaturedProducts from "@/components/FeaturedProducts"
import TrustBadges from "@/components/TrustBadges"
import VisitorCounter from "@/components/VisitorCounter"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-orange-50">
      <Header />
      <div className="max-w-6xl mx-auto">
        <HeroSection />
        <VisitorCounter />
        <TrustBadges />
        <FeaturedProducts />
      </div>
      <Footer />
    </div>
  )
}
