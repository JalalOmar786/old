"use client"

import { useState, useEffect } from "react"

export interface CartItem {
  id: number
  name: string
  price: number
  quantity: number
  color: string
  image: string
}

export function useCart() {
  const [cartItems, setCartItems] = useState<CartItem[]>([])
  const [isLoaded, setIsLoaded] = useState(false)

  // Load cart from localStorage on mount
  useEffect(() => {
    try {
      const savedCart = localStorage.getItem("storeheer-cart")
      if (savedCart) {
        const parsedCart = JSON.parse(savedCart)
        setCartItems(parsedCart)
      }
    } catch (error) {
      console.error("Error loading cart:", error)
    }
    setIsLoaded(true)
  }, [])

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    if (isLoaded) {
      try {
        localStorage.setItem("storeheer-cart", JSON.stringify(cartItems))
        // Trigger storage event for other components
        window.dispatchEvent(new Event("storage"))
      } catch (error) {
        console.error("Error saving cart:", error)
      }
    }
  }, [cartItems, isLoaded])

  const addToCart = (product: Omit<CartItem, "quantity">, quantity = 1) => {
    setCartItems((prev) => {
      const existingItem = prev.find((item) => item.id === product.id && item.color === product.color)

      if (existingItem) {
        return prev.map((item) =>
          item.id === product.id && item.color === product.color
            ? { ...item, quantity: item.quantity + quantity }
            : item,
        )
      } else {
        return [...prev, { ...product, quantity }]
      }
    })
  }

  const removeFromCart = (id: number, color: string) => {
    setCartItems((prev) => prev.filter((item) => !(item.id === id && item.color === color)))
  }

  const updateQuantity = (id: number, color: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(id, color)
      return
    }

    setCartItems((prev) => prev.map((item) => (item.id === id && item.color === color ? { ...item, quantity } : item)))
  }

  const clearCart = () => {
    setCartItems([])
  }

  const getTotalItems = () => {
    return cartItems.reduce((total, item) => total + item.quantity, 0)
  }

  const getTotalPrice = () => {
    return cartItems.reduce((total, item) => total + item.price * item.quantity, 0)
  }

  return {
    cartItems,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    getTotalItems,
    getTotalPrice,
    isLoaded,
  }
}
